import concurrent.futures
import json
import subprocess
import time
import xml.etree.ElementTree as ET
from collections import defaultdict
from pathlib import Path

root = Path.cwd()
out = root / '.tools/issue-294'
python = str(root / '.venv/bin/python')
revision = subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip()
assert not subprocess.check_output(['git', 'diff', 'HEAD', '--name-only'], text=True).strip()
collection = subprocess.check_output([python, '-m', 'pytest', '--collect-only', '-q'], text=True)
(out / 'final-collection.log').write_text(collection)
nodes = [line for line in collection.splitlines() if line.startswith('tests/') and '::' in line]
assert nodes and len(nodes) == len(set(nodes))
weights = defaultdict(float)
old_xml = out / 'final-pytest.xml'
if old_xml.exists():
    for case in ET.parse(old_xml).getroot().iter('testcase'):
        module = case.attrib.get('classname', '').split('.')
        if len(module) < 2:
            continue
        path = '/'.join(module[:2]) + '.py'
        node = '::'.join([path, *module[2:], case.attrib['name']])
        weights[node] += float(case.attrib.get('time', 0))
groups = [[], [], [], []]
loads = [0.0] * 4
for name in sorted(nodes, key=lambda n: weights[n], reverse=True):
    target = min(range(4), key=lambda i: loads[i])
    groups[target].append(name)
    loads[target] += max(weights[name], .001)
assert sorted(n for group in groups for n in group) == sorted(nodes)
record = dict(revision=revision, collected=len(nodes), groups=groups, results=[])
(out / 'final-suite-shards.json').write_text(json.dumps(record, indent=2) + '\n')

def run(index):
    command = [python, '-m', 'pytest', '-q', f'--junitxml={out}/final-shard-{index}.xml', *groups[index]]
    start = time.perf_counter()
    with (out / f'final-shard-{index}.log').open('w') as stream:
        result = subprocess.run(command, stdout=stream, stderr=subprocess.STDOUT)
    row = dict(shard=index, command=command, exit_code=result.returncode, seconds=time.perf_counter()-start)
    print(json.dumps(row), flush=True)
    return row

with concurrent.futures.ThreadPoolExecutor(max_workers=4) as executor:
    record['results'] = list(executor.map(run, range(4)))
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip() == revision
assert not subprocess.check_output(['git', 'diff', 'HEAD', '--name-only'], text=True).strip()
merged = ET.Element('testsuites', name='complete repository suite in four disjoint test groups')
for index in range(4):
    merged.extend(ET.parse(out / f'final-shard-{index}.xml').getroot())
assert sum(1 for _ in merged.iter('testcase')) == len(nodes)
ET.ElementTree(merged).write(old_xml, encoding='utf-8', xml_declaration=True)
(out / 'final-suite-shards.json').write_text(json.dumps(record, indent=2) + '\n')
raise SystemExit(any(r['exit_code'] for r in record['results']))
