import hashlib
import json
import os
import subprocess
import time
from pathlib import Path

root = Path.cwd()
out = root / '.tools/issue-294'
python = str(root / '.venv/bin/python')
commands = [
    ('ruff', [python, '-m', 'ruff', 'check', '.']),
    ('ruff-format', [python, '-m', 'ruff', 'format', '--check', '.']),
    ('yamllint', [python, '-m', 'yamllint', '.']),
    ('contract', [python, 'scripts/check_contract.py']),
    ('repository', [python, 'scripts/check_repository.py']),
    ('compose', ['docker', 'compose', '--env-file', '.env.example', '--profile', 'graph', 'config', '--quiet']),
    ('patch', ['git', 'diff', '--check', '340e8e526e1e693d4c4b55635c459985eb08fa49']),
    ('frozen-publication', ['git', 'diff', '--exit-code', 'f18e7af33584c1cc1c35b7b4fb208daf3c649769', '--', 'docs/research/awg-r03']),
]
results = []
for name, command in commands:
    start = time.perf_counter()
    with (out / f'check-{name}.log').open('w') as stream:
        result = subprocess.run(command, stdout=stream, stderr=subprocess.STDOUT, env={**os.environ, 'NEO4J_PASSWORD': 'ci-validation-placeholder'})
    results.append(dict(name=name, command=command, exit_code=result.returncode, seconds=time.perf_counter()-start, log=f'check-{name}.log'))
    print(name, result.returncode, flush=True)
archive = root / 'docs/research/awg-r03/AWG-R02_Experimental_Evidence.zip'
actual = hashlib.sha256(archive.read_bytes()).hexdigest()
expected = '9f0180fce0db17902e361857262a89ac6e89391df6460bf8b41812f082b1d64a'
results.append(dict(name='frozen-archive', exit_code=0 if actual == expected else 1, sha256=actual))
record = dict(revision=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(), results=results)
(out / 'checks.json').write_text(json.dumps(record, indent=2) + '\n')
raise SystemExit(any(r['exit_code'] for r in results))
