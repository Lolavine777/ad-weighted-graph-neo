import json
import subprocess
from pathlib import Path

root = Path.cwd()
session = root / '.tools/issue-294'
record = json.loads((session / 'final-suite-shards.json').read_text())
assert len(record['results']) == 4 and all(r['exit_code'] == 0 for r in record['results'])
assert subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip() == record['revision']
assert not subprocess.check_output(['git','diff','HEAD','--name-only'],text=True).strip()
python = str(root / '.venv/bin/python')
fixtures = ('two-routes','asrep','rbcd','rbcd-padding-1000')
for mode in ('benchmark', 'profile'):
    for prefix, repository in (('final-before', root.parent / 'issue-294-before'), ('final-after', root.parent / 'issue-294-after')):
        for fixture in fixtures:
            name = f'{prefix}-{fixture}' if mode == 'benchmark' else f'{prefix}-profile-{fixture}'
            command = [python, 'scripts/research/awg_r03_validation.py', '--repo', str(repository), '--evidence-root', str(session / 'frozen/AWG-R02'), '--output', str(session / 'runs' / name), '--mode', mode, '--fixture', fixture]
            print('start', name, flush=True)
            with (session / f'{name}.log').open('w') as stream:
                subprocess.run(command, stdout=stream, stderr=subprocess.STDOUT, check=True)
            print('done', name, flush=True)
for fixture in fixtures:
    before = session / 'runs' / f'final-before-{fixture}'
    after = session / 'runs' / f'final-after-{fixture}'
    assert (before / 'full-semantic.json').read_bytes() == (after / 'full-semantic.json').read_bytes()
print('All four full public semantic payloads are byte-equal before/after', flush=True)
