import json
import subprocess
from pathlib import Path

root = Path.cwd()
session = root / '.tools/issue-294'
scratch = session / 'profile-negative-control'
scratch.mkdir()
runs = scratch / 'runs'
runs.mkdir()
target_name = 'final-after-profile-two-routes'
for path in (session / 'runs').glob('final-*'):
    if path.name == target_name:
        target = runs / path.name
        target.mkdir()
        for name in ('native-measurement.json', 'full-semantic.json'):
            (target / name).write_bytes((path / name).read_bytes())
    else:
        (runs / path.name).symlink_to(path, target_is_directory=True)
target = runs / target_name
original = (target / 'native-measurement.json').read_bytes()
semantic = (target / 'full-semantic.json').read_bytes()
results = []
for name in ('stale-revision', 'tampered-semantic-file'):
    (target / 'native-measurement.json').write_bytes(original)
    (target / 'full-semantic.json').write_bytes(semantic)
    if name == 'stale-revision':
        record = json.loads(original)
        record['provenance']['revision'] = '0' * 40
        (target / 'native-measurement.json').write_text(json.dumps(record))
    else:
        (target / 'full-semantic.json').write_text('{}\n')
    output = scratch / name
    command = [str(root / '.venv/bin/python'), 'scripts/research/awg_r03_package.py', '--runs', str(runs), '--acceptance', str(session / 'accepted-comparison'), '--correctness-before', str(session / 'final-before-comparison'), '--audited-baseline', str(session / 'baseline-comparison'), '--junit', str(session / 'final-pytest.xml'), '--checks', str(session / 'checks.json'), '--output', str(output)]
    result = subprocess.run(command, capture_output=True, text=True)
    assert result.returncode != 0 and 'AssertionError' in result.stderr and not output.exists()
    (scratch / f'{name}.log').write_text(result.stdout + result.stderr)
    results.append(dict(case=name, rejected=True, exit_code=result.returncode, command=command))
(session / 'profile-negative-control.json').write_text(json.dumps(results, indent=2) + '\n')
print(json.dumps(results))
