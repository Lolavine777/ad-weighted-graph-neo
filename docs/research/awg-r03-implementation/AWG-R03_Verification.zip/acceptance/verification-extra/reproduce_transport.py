import json
import subprocess
from pathlib import Path

root = Path.cwd()
python = str(root / '.venv/bin/python')
session = root / '.tools/issue-294'
output = session / 'transport-proof'
output.mkdir()
records = []
for label, repository in (('audited-baseline', root.parent / 'issue-294-baseline'), ('accepted', root.parent / 'issue-294-after')):
    query = json.loads((repository / 'tests/fixtures/query_cli/two-routes-query.json').read_text())
    semantic = []
    revision = subprocess.check_output(['git','rev-parse','HEAD'], cwd=repository, text=True).strip()
    for variant, extra in (('omitted',{}),('null-graph',{'graph':None}),('null-catalog',{'catalog':None}),('both-null',{'graph':None,'catalog':None})):
        q = {k:v for k,v in query.items() if k not in ('graph','catalog')}
        q.update(extra)
        file = output / f'{label}-{variant}-query.json'
        file.write_text(json.dumps(q, indent=2) + '\n')
        destination = output / f'{label}-{variant}-result.json'
        command = [python,'-m','src.engine.query_cli','--query',str(file),'--graph','tests/fixtures/attack_scenarios/graphs/two-routes.json','--label','synthetic','--output',str(destination)]
        result = subprocess.run(command, cwd=repository, capture_output=True, text=True)
        expected = 0 if label == 'accepted' or variant == 'omitted' else 1
        assert result.returncode == expected, result.stderr
        if result.returncode == 0:
            semantic.append(json.loads(destination.read_text())['semantic'])
        records.append(dict(revision=revision, label=label, variant=variant, command=command, exit_code=result.returncode, stderr=result.stderr))
    if label == 'accepted':
        assert len(semantic) == 4 and all(s == semantic[0] for s in semantic)
(output/'results.json').write_text(json.dumps(dict(runs=records, accepted_full_semantics_equal=True),indent=2) + '\n')
print(json.dumps([(r['label'],r['variant'],r['exit_code']) for r in records]))
