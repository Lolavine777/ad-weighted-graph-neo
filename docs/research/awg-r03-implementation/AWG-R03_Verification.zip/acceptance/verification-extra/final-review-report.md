# Independent final review for issue #294

Reviewed snapshot: `1c43aca2df6dc9549e8efe5a51e38f23732fb817`.
Comparison: audited `340e8e526e1e693d4c4b55635c459985eb08fa49`, excluding the unchanged six-file publication imported at `f18e7af`.
This review inspected the supplied brief, HANDOFF requirements, complete implementation diff, production call paths, durable regressions, and the frozen harness functions called by the new validation runner.

## Verdicts

- **Spec compliance: changes requested for the final evidence packaging gate.**
  The three main production changes otherwise meet the reviewed requirements on static inspection: branch-local eligible actor scheduling, CLI null normalization with unsupported payload rejection, and bounded immutable catalog reuse carried into ranking replay.
  The package validator can currently accept profiles from a different implementation revision, so it does not establish the required revision-aware native profile comparison.
- **Code quality: changes requested.**
  One medium-severity evidence validation defect and one low-severity loader compatibility regression are detailed below.
  I found no additional concrete defect in actor composition, existing evaluator authorization, source/request attribution, first-goal handling, used-action restrictions, cap accounting, or unknown/False handling.

## Findings

### P2 - Bind each profile record to its paired benchmark provenance

Location: `/workspaces/ad-weighted-graph/.worktrees/issue-294/scripts/research/awg_r03_package.py:97` through line 128, especially lines 114-125.

The package reads both benchmark and profile measurement files, but it only checks the profile's semantic digest against the benchmark.
The subsequent revision, dirty-state, runner, interpreter, dependency, and input checks apply exclusively to the benchmark records.
Semantic equality is expected across this optimization, so that digest cannot establish which source generated the profile.

Concrete failure scenario: regenerate `final-after-rbcd` at revision B while leaving `final-after-profile-rbcd` from revision A.
If A and B have identical semantic output, packaging succeeds and retains A's parse counts and profile timings alongside B's benchmark as the selected final comparison.
The same issue allows a profile produced using a different fixture input or environment to pass whenever its normalized public semantic result happens to match.
This can undermine the structural work-reduction evidence even when the production implementation is correct.

For every fixture and mode, verify that the profile matches its benchmark's revision, tree, empty tracked-change set, patch identity, runner hash, interpreter, dependencies, platform/environment, fixture name, and input hash.
Also verify each record's fixture against the fixture selected by the loop, and hash the profile directory's retained `full-semantic.json` against its own declared digest.
Keep the existing checks that bind the benchmark revisions to the correctness runs and compare before/after semantic results.

### P3 - Preserve the existing empty-string default catalog fallback

Location: `/workspaces/ad-weighted-graph/.worktrees/issue-294/src/engine/semantics/catalog.py:421`.

The previous loader used `Path(path or DEFAULT_PATH)`, while this implementation defaults only when `path is None`.
An existing caller passing `load_catalog("")`, for example from an optional CLI/configuration value, previously loaded the default catalog.
It now constructs `Path("")`, resolves to the current directory, and fails in `read_bytes()` with `IsADirectoryError`.

This compatibility change is unrelated to byte-keyed caching and is unnecessary in a performance-only catalog slice.
Preserve the prior falsey-string fallback and add one focused regression for `load_catalog("")` matching the default loader.
The practical severity is low because no in-repository caller relying on the empty-string case was identified during this review.

## Reviewed safeguards and regression quality

The scheduler enumerates the initial actor and identities usable in the matching authentication context from each accumulated branch state.
It creates no actor-switch transition and retains the existing evaluator and `apply_transition` boundary.
Its shared candidate iterator is used both for expansion and step-limit accounting, and remaining candidates from another eligible actor participate in path/expansion truncation decisions.
The restored unions retain branch-derived permissions and withheld relationships before existing authorization filters, preserving the withheld-HasSession indeterminate diagnostic.

The actor regressions require the exact U:H1 -> V:H2 -> U:H3 program, real activation followed by return, wrong-context and uncontrolled negatives, unique programs, initial attribution, and remaining-actor cap behavior.
The source-A expectation is derived from the declarative action inventory and independently enumerated dependency orderings, rather than copied from generated planner output.
The AS-REP expectation change is consistent with exhausting its sole first-goal program exactly at `max_paths=1`.

The catalog cache has a bounded 32-entry `lru_cache`, uses exact file bytes as its key, and returns frozen `Technique` records with tuple fields.
The authoritative recipe lookup remains separate from the supplied custom catalog, RBCD recipe equality is retained, and artifact executable-gate checks remain intact.
Removing the owner-only credential recipe cache avoids permanently stale default recipes.
The prepared catalog is passed through both ranking orchestration entry paths into semantic replay.
No runtime facts, states, applicability results, or ratings are cached.

The CLI change strips only null `graph` and `catalog` fields before the existing embedded-payload rejection.
The regressions compare complete normalized semantic payloads across omitted/null variants and retain real graph/catalog/candidate rejection cases.

The new validation runner operates on a copied historical harness, verifies frozen file checksums, selects an explicit source checkout, keeps timing separate from cProfile, records catalog setup separately, and retains full public semantic output for parity checks.
The package provenance omission above is the concrete remaining issue found in that tooling.

## Verification limitations

This was a read-only code review of the named snapshot.
I did not run tests, benchmarks, profiles, acceptance scripts, or bug reproducers, and I did not modify production or test source.
The primary agent is independently running the complete final verification, so no pass count, runtime result, timing, or speedup is asserted here.
The two findings follow directly from the reviewed control flow and parameter semantics.

## 2026-10-16 amendment - Package provenance re-review

Reviewed the current working diff for `scripts/research/awg_r03_package.py` after the primary agent addressed P2.
The original snapshot verdict above remains the historical assessment of `1c43aca2df6dc9549e8efe5a51e38f23732fb817`.

**P2 is resolved on static inspection of this working diff.**
Lines 99-115 bind each profile to its benchmark through the selected fixture, revision, tree, dirty state, patch, runner, interpreter, platform, dependencies, frozen evidence identity, and input hash.
Lines 129-135 verify the retained semantic JSON in both directories against each record's digest before comparing them.
Lines 139-150 retain the correctness-revision bindings and before/after comparisons, and now include platform equality.
Consequently, a stale profile with a different source revision or other checked identity no longer passes merely because its semantic output is unchanged.

No new concrete issue was found in this package-only follow-up.
I ran no runtime checks or negative control.
The primary agent will run the deliberate stale-profile rejection check against final real outputs.
P3 and subsequent source-A work were outside this follow-up's review scope.

## 2026-10-16 amendment - Source-A historical oracle and source-successor re-review

Reviewed the current working diffs in `scripts/research/scenario_rating_pack.py`, `scripts/research/likelihood_catalog.py`, `scripts/research/rating_source_successors.py`, `tests/test_source_a_rating_pack.py`, and `tests/test_rating_source_successors.py`.
The newly referenced source manifests have intentionally not yet been generated, pending the worker's final source changes.

**No new concrete finding in these reviewed diffs.**
The source-successor generator advances to likelihood v8 and scenario v9, refuses to overwrite either destination, copies predecessor metadata, hashes the predecessor, and refreshes the current-source pins in new files.
The verifiers retain historical file digest checks, retain exact current-source coverage and digest checks, and add the previous latest manifests to their historical hash-chain checks.
The source-successor tampering regressions continue to cover historical pins, predecessor/ancestor bytes, missing coverage, and current-source drift.
No historical artifact edit is present in the reviewed working diff.

The Source-A probe now matches every frozen witness by its complete ordered action sequence, including passive membership actions, before resolving its current generated candidate ID.
It still checks each of the historical 24 programs against its frozen C/P/I values, preserves the frozen minimum and frontier through semantic ID remapping, and rejects duplicate programs.
It requires every additional program to remain outside the eligible set with no numeric likelihood interval.
It preserves C/I unique coverage and the number of rated P requests, and derives the expanded P-unrated count from actual candidate coverage summaries.
No numeric evidence, intervals, provider gates, or frozen expectations are added or modified by these changes.

The pending Source-A regression requires exactly the independent model's 330 first-goal programs, with exact set equality and no duplicate allowance through the path count.
The simulated-review regression repeats model equality, verifies semantic remapping of the frozen witnesses and exact products, expects only two fully rated programs and 328 P-unrated programs, and retains the C/I-complete and likelihood-only refusal checks.
The imported finite model reads the declarative action inventory rather than planner-generated output.

I did not execute tests, generators, benchmarks, or profiles.
Generated successor contents and the worker-owned catalog/release-test changes remain outside this amendment's review scope.
The primary agent must generate the successors only after all pinned source changes are final and validate their exact hashes and historical artifact preservation.

## 2026-10-16 amendment - Final loader, release-test, and generated-successor review

Reviewed the stable working diffs in `src/engine/semantics/catalog.py`, `tests/test_catalog_reuse.py`, and `tests/test_final_cpi_release.py` on top of `bc0cced`.
Also inspected the generated likelihood v8 and scenario v9 source manifests.

**P3 is resolved on static inspection.**
The loader restores the original `path or default` behavior before reading content through the bounded byte-keyed cache.
The new regression compares the empty-string, explicit-None, and omitted-path loads and requires a nonempty result.
This does not change explicit nonempty catalog paths or cache identity.

**No new concrete finding in this final follow-up.**
The release-test edits replace only the obsolete 24-path expectations with the independent finite model's exact program set and cardinality.
The same model's 330-program cardinality is pinned in the profile and pending Source-A tests reviewed earlier.
The release tests retain simulated review authority, pending refusal, immutable input checks, full numeric provenance checks, rejected-dimension refusal, exact first-path C/P/I values, and the public comparator's independent checks.
The all-program numeric expectation applies only to the explicitly simulated adopted release with its existing declared history model.
It does not alter the frozen Source-A transfer probe's requirement that newly reachable programs remain P-unrated.
No production rating code, numeric record, interval, or approval metadata is changed by these release-test edits.

A read-only JSON/hash inspection confirmed that each generated successor preserves all predecessor metadata outside schema version, predecessor hash, and refreshed source pins.
Both predecessor hashes match their retained files, their source-pin name sets are unchanged, and all 32 likelihood pins and 31 scenario pins match current file bytes, including the final catalog fallback.
The rating-artifact diff against the audited baseline contains only the two added successor files.
No existing historical rating artifact is modified.

The original two review findings are now resolved on static inspection of their respective follow-up diffs.
The reviewed implementation and follow-up changes have no outstanding concrete code-review finding.
I did not run tests, generators, benchmarks, profiles, or production validators.
Execution results and the deliberate stale-profile negative control remain the primary agent's separate verification evidence.

## 2026-10-16 amendment - Acceptance follow-up commits

Reviewed exact commits `0810a28ac591ea72bc18d29ad125957a46240adb` and `d729a7031350edcb7af3ac5a3d6e1e266a2394cc` against the scoped acceptance brief.
They change only the three named test modules and add the two new generated acceptance records.
No production source is changed by these commits.

**Spec compliance and code quality: no outstanding concrete finding in this scoped follow-up.**
The raw-only test changes skip solely when the required raw directory is absent.
They do not catch parser, manifest, semantic, or bounded-assumption failures when that directory exists, and all existing bounded-assumption assertions remain.

The acceptance test retains the literal historical hashes and existing historical-fixture reconciliation.
It requires the new normalized cases to differ only at `W4-K-OVERLAP`, requires the literal new `path_limit_reached` reason, restores only the previous reason and evidence digest in a copy, recomputes that copy's output digest, and compares the complete payload to normalized v2.
Both the live run's semantic payload and the new recorded manifest must match cases v3.
The independent verdict assertions remain unchanged.

Read-only JSON comparison independently confirmed exactly three changed semantic leaf fields after the existing raw prerequisite normalization: `W4-K-OVERLAP.actual.extension_truncation_reason`, its `evidence_digest`, and its `output_digest`.
All 38 case IDs, verdicts, normative flags, and independent assertion records are unchanged.
The new manifest's semantic projection exactly equals cases v3.
Its recorded summary is 36 PASS, one unavailable prerequisite, one not executed, and zero unexpected failures.
These artifact observations do not represent an additional execution by this reviewer.

The K-overlap full evidence records 50 generated paths, `max_paths=50`, `truncated=true`, `truncation_reason=path_limit_reached`, and `search_complete=false`.
The added assertions require each of those fields explicitly, so reaching the path cap cannot be reported as exhausted coverage.

All 126 generated manifest file hashes match current file bytes, and the source/input digest matches the complete pin mapping.
Its recorded source identity is clean commit `0810a28ac591ea72bc18d29ad125957a46240adb`, with no dirty pinned files.
Read-only comparison against pre-follow-up commit `d7f5269` confirms byte preservation of guided manifest v4, maintainer cases v2, and maintainer manifest v2.
The latter two retain their literal test hashes `dec17ae2c8fc39faa320ca5c1487bb3087f7fe319cd2cdb81145149d16d50bae` and `1623c1c9e505550374402fdd5714de0a0eebb3a63d75eab0c825e19de3269dd9`.

I did not run runtime tests, generators, benchmarks, or profiles for this amendment.
The final full suite remains the primary agent's independent verification.

## 2026-10-16 amendment - JUnit case/subtest accounting

Reviewed the final working diff in `scripts/research/awg_r03_package.py` that separates pytest testcase elements from successful subtests included only in the suite total.

**No new concrete finding in this accounting fix.**
The package still rejects nonzero suite failure/error totals.
It now requires a positive testcase count no greater than the JUnit reported total and requires the number of skipped testcase elements to equal the suite skipped total.
It reports collected cases, passed cases, successful subtests, and the original JUnit reported total separately.
For the input structure described by the primary agent, 3,286 testcase elements minus 140 skipped cases yields 3,146 passed cases, and 3,385 reported checks minus 3,286 testcase elements yields 99 successful subtests.
Those arithmetic observations do not assert an additional suite execution by this reviewer.

The change does not alter production code, tests, configs, semantic comparisons, benchmark/profile provenance checks, or acceptance gates.
I did not run tests, profiles, or packaging controls.
The primary agent retains responsibility for the complete package positive control and stale-profile negative control.
