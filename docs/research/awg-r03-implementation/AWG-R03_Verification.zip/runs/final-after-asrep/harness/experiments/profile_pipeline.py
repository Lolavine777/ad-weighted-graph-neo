"""F2: measured stock pipeline, immutable-catalog cache, and narrow state merge.

All changes are monkeypatches scoped to an experiment; upstream stays unchanged.
The merge experiment is ONLY monotone reachability / unit active-goal cost with
zero-cost membership, not Top-K ordered programs, P, arbitrary shared work or AD.
"""
from collections import deque
from contextlib import ExitStack, contextmanager
from copy import deepcopy
from dataclasses import replace
import cProfile
import hashlib
import importlib
import json
import pstats
import resource
import statistics
import sys
import time
from unittest.mock import patch

from cases import BASE, IDS, ROOT, facts, graph, member_facts, query
from src.engine.graph import EngineGraph
from src.engine.query import MaterializedQuery, materialize_query
from src.engine.query_cli import wire
from src.parser.snapshot_facts import graph_digest, serialize_snapshot

EVIDENCE=ROOT/'evidence'


def save(name,value):
    (EVIDENCE/name).write_text(json.dumps(value,ensure_ascii=False,indent=2,sort_keys=True)+'\n')


@contextmanager
def catalog_cache(enabled):
    """Reuse immutable catalog only for this fixed SHA + unchanging default file."""
    import src.engine.semantics.catalog as catalog
    source=catalog.ROOT/'configs/attack_semantics.yml'
    before=hashlib.sha256(source.read_bytes()).hexdigest()
    original=catalog.load_catalog
    stats={'setup_seconds':0.0,'hits':0,'source_sha256':before,'scope':'fixed process, exact default file bytes only'}
    with ExitStack() as stack:
        if enabled:
            start=time.perf_counter();frozen=original();stats['setup_seconds']=time.perf_counter()-start
            frozen_digest=hashlib.sha256(json.dumps(wire(frozen),sort_keys=True).encode()).hexdigest()
            def cached(path=None):
                if path is None or str(path)==str(source):
                    stats['hits']+=1
                    return frozen
                return original(path)
            modules=[catalog]+[importlib.import_module(n) for n in ('src.engine.semantics','src.engine.semantics.evaluator','src.engine.search','src.engine.query')]
            for module in modules:
                if getattr(module,'load_catalog',None) is original:
                    stack.enter_context(patch.object(module,'load_catalog',cached))
        yield stats
        assert hashlib.sha256(source.read_bytes()).hexdigest()==before
        if enabled:
            assert hashlib.sha256(json.dumps(wire(frozen),sort_keys=True).encode()).hexdigest()==frozen_digest


def fixture(name):
    started=time.perf_counter()
    if name=='two-routes':
        g=EngineGraph.from_canonical((BASE/'tests/fixtures/attack_scenarios/graphs/two-routes.json').read_text())
        q=json.loads((BASE/'tests/fixtures/query_cli/two-routes-query.json').read_text())
        q['ranking_query']=json.loads((BASE/'docs/research/ratings/week4/synthetic-a2-e.json').read_text())['query']
        q['top_k']=3
    else:
        module=importlib.import_module('scripts.research.asrep_inputs' if name=='asrep' else 'scripts.research.rbcd_inputs')
        g,q=module.inputs()
        packet,bindings=module.ranking_inputs(g,q)
        q.update(ranking_query=packet,action_bindings=[[list(k),v] for k,v in bindings.items()])
    generation=time.perf_counter()-started
    if name=='rbcd-padding-1000':
        canonical=g.to_canonical();provenance=deepcopy(canonical['edges'][0]['provenance'])
        from scripts.check_contract import canonical_edge_id
        for i in range(1001):
            sid=f'S-1-5-21-1000-2000-3000-{10000+i}'
            canonical['nodes'].append(dict(id=sid,kind='Group',label='IRRELEVANT',domain='EXAMPLE.TEST',is_boundary=False,enabled=True))
            if i:
                prev=f'S-1-5-21-1000-2000-3000-{9999+i}'
                canonical['edges'].append(dict(id=canonical_edge_id(prev,sid,'MemberOf'),source=prev,target=sid,kind='MemberOf',weight=1.0,provenance=deepcopy(provenance)))
        sf=replace(g.snapshot_facts,graph_sha256=graph_digest(canonical))
        g=EngineGraph.from_snapshot(serialize_snapshot(canonical,sf))
    canonical=g.to_canonical()
    if g.snapshot_facts is not None:
        transport=serialize_snapshot(canonical,g.snapshot_facts)
        load=lambda:EngineGraph.from_snapshot(transport)
    else:
        transport=json.dumps(canonical)
        load=lambda:EngineGraph.from_canonical(transport)
    save('f2-input-'+name+'.json',dict(graph=canonical,snapshot_facts=wire(g.snapshot_facts),query=q))
    return load,q,dict(nodes=len(canonical['nodes']),edges=len(canonical['edges']),input_factory_seconds=generation,transport_bytes=len(transport.encode()))


def trial(load,q):
    t=time.perf_counter();g=load();graph_seconds=time.perf_counter()-t
    t=time.perf_counter();m=materialize_query(q,g);materialize_seconds=time.perf_counter()-t
    t=time.perf_counter();search=m.search(g);search_seconds=time.perf_counter()-t
    import src.engine.ranking.verification as verification
    import src.engine.ranking.assessment as assessment
    replay_stats={'semantic_seconds':0.0,'semantic_calls':0,'fact_seconds':0.0,'fact_calls':0}
    def instrument(original,name):
        def wrapped(*args,**kwargs):
            t=time.perf_counter()
            try:
                return original(*args,**kwargs)
            finally:
                replay_stats[name+'_seconds']+=time.perf_counter()-t
                replay_stats[name+'_calls']+=1
        return wrapped
    with patch.object(MaterializedQuery,'search',return_value=search), \
         patch.object(verification,'replay_path',instrument(verification.replay_path,'semantic')), \
         patch.object(assessment,'replay_candidate_sequence',instrument(assessment.replay_candidate_sequence,'fact')):
        t=time.perf_counter();result=m.run(g);rating_seconds=time.perf_counter()-t
    payload=dict(search=search,ranking=result.ranking_result,min_effort=result.min_effort,top_k=result.top_k_result,
                 diagnostics=result.diagnostics,binding_diagnostics=result.binding_diagnostics,final_goal_reached=result.final_goal_reached)
    t=time.perf_counter();encoded=json.dumps(wire(payload),sort_keys=True,ensure_ascii=False).encode();serialization_seconds=time.perf_counter()-t
    digest=hashlib.sha256(encoded).hexdigest()
    replay=replay_stats['semantic_seconds']+replay_stats['fact_seconds']
    return dict(graph_seconds=graph_seconds,materialize_seconds=materialize_seconds,search_seconds=search_seconds,
                rating_inclusive_seconds=rating_seconds,replay_seconds=replay,rating_exclusive_seconds=rating_seconds-replay,
                serialization_seconds=serialization_seconds,serialized_bytes=len(encoded),digest=digest,
                replay_breakdown=replay_stats,path_count=len(search.paths),expansions=search.expansions,
                complete=search.complete,goal=result.final_goal_reached,
                min_C=result.min_effort.get('minimum_effort_value') if result.min_effort else None,
                total_seconds=graph_seconds+materialize_seconds+search_seconds+rating_seconds+serialization_seconds,
                process_max_RSS_KiB=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss)


def profile_search(load,q,filename):
    g=load();m=materialize_query(q,g)
    profile=cProfile.Profile();profile.runcall(m.search,g)
    profile.dump_stats(str(EVIDENCE/(filename+'.pstats')))
    s=pstats.Stats(profile)
    rows=[]
    for (file,line,name),(primitive,total,own,cumulative,callers) in s.stats.items():
        rows.append(dict(file=file.replace(str(BASE),'baseline'),line=line,name=name,primitive_calls=primitive,calls=total,own_seconds=own,cumulative_seconds=cumulative))
    rows.sort(key=lambda r:r['cumulative_seconds'],reverse=True)
    save(filename+'.json',dict(total_seconds=s.total_tt,total_calls=s.total_calls,top_cumulative=rows[:35],
                              selected=[r for r in rows if r['name'] in {'load_catalog','safe_load','deepcopy','__getitem__','evaluate_rbcd','generate_attack_paths','validate_binding','validate_graph'}]))


class MergeQueue:
    """Narrow F2 counterfactual: keep the same generator/evaluator, merge schedules.

Key includes actor, COMPLETE AttackState, used actions, and remaining step budget
(history length). It omits history only for the audited passive-membership / one
unit-cost terminal action fixture. Not safe for full-history P or Top-K programs.
"""
    latest=None
    def __init__(self,iterable=()):
        self.queue=deque();self.seen=set();self.suppressed=0;MergeQueue.latest=self
        for item in iterable:self.append(item)
    def append(self,item):
        actor,state,nodes,edges,history,used,origins=item
        k=(actor,state,used,len(history))
        if k in self.seen:self.suppressed+=1;return
        self.seen.add(k);self.queue.append(item)
    def popleft(self):return self.queue.popleft()
    def __len__(self):return len(self.queue)
    def __bool__(self):return bool(self.queue)


def fanout(n):
    # Reuse the canonical input adapter, not a second semantic system.
    # The adapter classifies G* as Group.
    for i in range(1,n+1):IDS[f'G{i}']=f'S-1-5-21-1000-2000-3000-{8000+i}'
    edges=[('U','MemberOf',f'G{i}') for i in range(1,n+1)]+[(f'G{i}','AdminTo','H1') for i in range(1,n+1)]
    g=graph(f'fanout-{n}',edges)
    runtime=sum((member_facts('U',f'G{i}') for i in range(1,n+1)),[])+facts('admin_channel authentication_accepted','U','H1')
    q=query('H1',{'admin_control':[IDS['H1']]},runtime,['propagate_group_entitlement','obtain_admin_execution_on_host'])
    q['budget']=dict(max_steps=n+1,max_paths=50000,max_expansions=200000)
    return g,q


def merge_probe(n):
    import src.engine.search as search_module
    g,q=fanout(n);m=materialize_query(q,g)
    cases={}
    for mode in ('stock','merge'):
        times=[];last=None;suppressed=0
        for _ in range(3):
            with patch.object(search_module,'deque',MergeQueue if mode=='merge' else deque):
                start=time.perf_counter();last=m.search(g);times.append(time.perf_counter()-start)
                suppressed=MergeQueue.latest.suppressed if mode=='merge' else 0
        assert last.complete and last.paths
        signatures={tuple(sorted((user,group) for user,group in path.final_state.effective_member)) for path in last.paths}
        # Independent combinatorial oracle: any nonempty subset of n memberships
        # can precede terminal admin; active C=1 regardless of passive order.
        assert len(signatures)==2**n-1
        assert all(not path.final_state.control for path in last.paths)
        cases[mode]=dict(seconds=times,median_seconds=statistics.median(times),path_count=len(last.paths),expansions=last.expansions,
                         unique_goal_membership_sets=len(signatures),goal=True,min_active_C=1,complete_within_declared_domain=True,
                         all_ordered_programs_preserved=mode=='stock',suppressed_queue_entries=suppressed,
                         states_hash=hashlib.sha256(json.dumps(sorted(signatures)).encode()).hexdigest())
    assert cases['stock']['states_hash']==cases['merge']['states_hash']
    return cases


def main():
    output=dict(experiment='AWG-R02/F2',repeats='one first query + three subsequent queries per mode; medians of subsequent queries',fixtures=[],merge_probes={})
    for name in ('two-routes','asrep','rbcd','rbcd-padding-1000'):
        load,q,meta=fixture(name);record=dict(name=name,metadata=meta,modes={})
        for enabled in (False,True):
            mode='immutable-catalog-cache' if enabled else 'stock'
            _recipe.cache_clear()
            with catalog_cache(enabled) as cache:
                trials=[]
                for i in range(4):
                    r=trial(load,q);trials.append(r)
                    print(json.dumps(dict(fixture=name,mode=mode,trial=i,total_seconds=r['total_seconds'],search_seconds=r['search_seconds'],paths=r['path_count'],complete=r['complete'])),flush=True)
                assert len({r['digest'] for r in trials})==1
                timing_keys=[k for k in trials[0] if k.endswith('_seconds')]
                summary={k:statistics.median(t[k] for t in trials[1:]) for k in timing_keys}
                if name in {'rbcd','rbcd-padding-1000'}:
                    profile_search(load,q,'f2-profile-'+name+'-'+mode)
                record['modes'][mode]=dict(cache=dict(cache),first_query=trials[0],subsequent_queries=trials[1:],median=summary)
        assert record['modes']['stock']['first_query']['digest']==record['modes']['immutable-catalog-cache']['first_query']['digest']
        record['exact_output_digest_equal']=True
        output['fixtures'].append(record);save('f2-results.json',output)
    # These are search-only and have a narrower output contract than Top-K.
    for n in (3,4,5,6):
        output['merge_probes'][str(n)]=merge_probe(n)
        save('f2-results.json',output)
        print(json.dumps(dict(fanout=n,results=output['merge_probes'][str(n)])),flush=True)


if __name__=='__main__':main()
