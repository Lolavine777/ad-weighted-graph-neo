# AWG-R02 — Reproducible experimental audit

Baseline: `nairyuuu/ad-weighted-graph@340e8e526e1e693d4c4b55635c459985eb08fa49`.
Audit executed on 2026-10-16, CPython 3.14.8. Read the Vietnamese report
`AWG-R02_Bao_cao_thuc_nghiem.md` for conclusions and limitations.

This bundle contains experiments and retained evidence, not a production patch.
No upstream repository source or virtual environment is bundled. All AD IDs,
graphs and runtime declarations in the new fixtures are synthetic. Source
commit/tree metadata is retained for provenance.

## Recreate the baseline

Use a new directory for this bundle and an authenticated Git environment that
has read access to the repository. Do not run against an existing development
checkout. From the bundle root:

```bash
git clone --no-checkout https://github.com/nairyuuu/ad-weighted-graph.git baseline
git -C baseline switch --detach 340e8e526e1e693d4c4b55635c459985eb08fa49
python3.14 -m venv .venv
.venv/bin/python -m pip install -r baseline/requirements-tests.txt
```

`evidence/requirements-frozen.txt` records all installed distributions in the
audit. Runtime 3.14 is needed for the upstream PEP 695 type-alias syntax. A full
clone is fine; the audit itself materialized a SHA-verified sparse local Git
checkout through GitHub API because its Git endpoint lacked authentication.
`experiments/materialize_git.py` records that acquisition method, not a required
bootstrap command. Never run that script on a normal working checkout.

## Run in order, without concurrent benchmark/test processes

Commands below intentionally write new evidence at the same relative paths;
keep a copy of the retained evidence before re-running. The report is a frozen
record of the audit session; different hardware will produce different timing.

```bash
bash experiments/run_f0.sh > evidence/f0-complete.log 2>&1
.venv/bin/python experiments/run_baseline_probes.py > evidence/f0-probes-run.log 2>&1
.venv/bin/python -u experiments/run_ablation.py > evidence/f1-run.log 2>&1
.venv/bin/python experiments/run_cost_probe.py > evidence/f1-shared-work-run.log 2>&1
.venv/bin/python experiments/reproduce_actor_gap.py > evidence/actor-gap-public-api.json
.venv/bin/python -u experiments/profile_pipeline.py > evidence/f2-run.log 2>&1
.venv/bin/python experiments/profile_rating.py > evidence/f2-profile-rating-run.log 2>&1
.venv/bin/python experiments/verify_evidence.py
```

The test command selects exactly nine existing test modules. The final retained
run has 310 tests passed. Earlier F0 logs retain missing-fixture / Git-metadata
failures while materializing the sparse checkout, not production code fixes.

The oracle and two alternatives import no AWG modules. `cases.py` manually
defines finite grounded actions and literal expected outcomes, and prepares
native AWG inputs. It reuses existing synthetic fixture input builders for
AS-REP, Kerberoasting and RBCD, not native candidate/transition/cost code to
construct expected outcomes. `run_ablation.py` checks native witnesses against
the independent oracle and native replay as an additional differential check.

F1 intentionally does **not** fail the process for the documented actor-search
mismatch. It records it in `f1-results.json.summary.mismatches`; there must be
exactly one mismatch at this audited baseline. Unexpected witness invalidity,
oracle/literal discrepancy, alternative reachability mismatch, cost mismatch in
the supported unary domain, or native replay failure raises an assertion.

`run_cost_probe.py` additionally exercises the actual native ranking layer. A=2,
B=4+1 and the suffix reuses B. The independently expected minimum is 5; P/I are
unrated. The data are synthetic test values, not calibrated AD effort.

`profile_pipeline.py` runs 32 instrumented wall-clock pipeline trials, four
separate search cProfile passes, and 24 search-only state-merge trials. The
rating phase receives precomputed search through a scoped monkeypatch, so
search is not counted twice. Semantic and fact replay times are subtracted
from inclusive rating for the exclusive rating field. The cache monkeypatch
freezes only the unchanged default catalog in that process, preserves recipe
validation, and asserts exact output hashes. Cache construction is reported
separately. `profile_rating.py` adds one separate rating/replay cProfile pass.

The merge queue is narrowly valid for the passive-membership fixture and its
reachability/state-set/unit-terminal-cost objective. It does not preserve every
ordered program and is not a proposed general dominance key for P, shared work
or Top-K. No alternative end-to-end performance claim is made: the lightweight
conditional graph and AND-OR receive hand-grounded actions and have no real AD
grounder, parser, provenance ingestion, or production witness cost optimizer.

No private SEAMLESS raw files, AD lab, Neo4j, live attack execution, probability
calibration, full-SEAMLESS timing, migration or production refactor is included.

## Key evidence

- `source-provenance.json`, `f0-probes.json`: source/object hashes, clean baseline,
  API/CLI null-key mismatch and truncation guarantee control.
- `audited-source-files.json`: the fixed 126-file subset verified during this
  audit, also used when re-running the checks against a full repository clone.
- `f0-complete.xml/.log`: final focused baseline test result.
- `f1-inputs/`, `f1-results.json`: 78 variants, expected outcomes, independent
  oracle/alternatives/native traces, gate diagnostics and input SHA-256.
- `f1-shared-work-native-rating.json`: native cost/proof/Top-K check.
- `actor-gap-public-api.json`: explicit evaluator-valid U -> V -> U trace versus
  search `no_path, complete=true` at the same baseline.
- `f2-results.json/.log`: final wall-clock trials; `f2-pilot-*` are superseded
  exploratory measurements and are not used for the report's timing table.
- `f2-profile-*.json/.pstats`: profile data. Binary pstats files are runtime/OS
  specific; portable JSON extracts retain relevant call counts and hotspots.
- `final-qa.json`: consistency checks on retained evidence, not new product tests.
- `MANIFEST-SHA256.txt`: checksums, excluding itself and external baseline/venv.

`build_report.py` records how the written audit was assembled. Its prose is an
audit narrative, not an automatic publication template for arbitrary future
runs. Revisit the findings and fixed execution details before republishing it.
