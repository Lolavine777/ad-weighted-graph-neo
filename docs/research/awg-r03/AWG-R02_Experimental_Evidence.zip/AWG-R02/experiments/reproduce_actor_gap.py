"""Reproduce a supported API/evaluator/search discrepancy at the audited SHA."""
import json
from cases import IDS, case9
from src.engine.query import materialize_query
from src.engine.query_cli import wire
from src.engine.semantics import TransitionRequest, apply_transition, evaluate
from src.engine.semantics.evaluator import PreparedSemanticGraph
from src.engine.semantics.transitions import Status

c=case9()[0]
m=materialize_query(c.query,c.graph)
result=m.run(c.graph)
prepared=PreparedSemanticGraph(c.graph.to_canonical(),snapshot_facts=c.graph.snapshot_facts)
state=m.initial_attack_state
steps=[]
for actor,host in [('U','H1'),('V','H2'),('U','H3')]:
    request=TransitionRequest('obtain_admin_execution_on_host',IDS[actor],IDS[actor],IDS[host])
    step=evaluate(prepared,state,request,m.runtime_context,m.catalog)
    assert step.status is Status.APPLICABLE
    state=apply_transition(state,step)
    steps.append(dict(actor=actor,target=host,status=step.status.value))
assert m.is_success_state(state)
assert not result.paths and result.complete
print(json.dumps(wire(dict(status=result.status,goal=result.final_goal_reached,complete=result.complete,
                           caps=result.caps,manual_evaluator_replay=dict(steps=steps,goal=True),
                           query=c.query,graph=c.graph.to_canonical())),ensure_ascii=False,indent=2))
