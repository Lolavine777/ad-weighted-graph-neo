"""Manually grounded instances for the 12 R01 ablations; AWG input adapter only.

The expected outcomes, action prerequisites/effects and work ledgers below are
authored independently, not extracted from AWG transitions or ranking results.
Existing fixture builders are used ONLY to prepare incumbent inputs for cases
5-8. No attempt to reimplement the full AD semantic rule catalog.
"""
from copy import deepcopy
from dataclasses import asdict, dataclass, replace
import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
BASE = ROOT / "baseline"
sys.path.insert(0, str(BASE))
from oracle import Action, Problem
from scripts.check_contract import canonical_edge_id
from src.engine.graph import EngineGraph
from src.engine.semantics.rbcd_types import DelegationArtifact, DelegationBinding

IDS = {n: f"S-1-5-21-1000-2000-3000-{1101+i}" for i, n in enumerate(("U", "V", "W", "G1", "G2", "G3"))}
IDS.update({n: f"10000000-0000-4000-8000-{i:012d}" for i, n in enumerate(("X", "H1", "H2", "H3", "Y"), 1)})


def a(name, requires, adds, work=(), guards=()):
    return Action(name, frozenset(requires), frozenset(adds), frozenset(work), tuple(guards))


def graph(name, edges, extra=()):
    names = set(extra) | {n for s, _, t in edges for n in (s, t)} | {"U", "X"}
    result = deepcopy(json.loads((BASE / "data/samples/toy-graph.json").read_text()))
    result["metadata"].update(description=f"AWG-R02 finite experiment {name}", code_version="r02/grounded-v1")
    result["assessments"] = []
    result["nodes"] = [dict(id=IDS[n], label=n, kind="Computer" if n in {"X", "Y", "H1", "H2", "H3"} else "Group" if n.startswith("G") else "User", domain="EXAMPLE.TEST", is_boundary=False, enabled=True) for n in sorted(names)]
    result["edges"] = [dict(id=canonical_edge_id(IDS[s], IDS[t], kind), source=IDS[s], target=IDS[t], kind=kind, weight=1.0,
                            provenance=[dict(raw_file=f"synthetic://r02/{name}", collector="r02", timestamp="2026-10-16T00:00:00Z", evidence_type="positive")]) for s, kind, t in edges]
    return EngineGraph.from_canonical(result)


def fact(predicate, subject, target, value=True):
    return dict(predicate=predicate, subject=IDS.get(subject, subject), target=IDS.get(target, target), value=value,
                origin="declared_assumption", scope="r02/finite-fixture", rationale="Synthetic declared guard; not observed frequency", provenance_reference="synthetic://r02/guards")


def facts(predicates, subject, target):
    return [fact(p, subject, target) for p in predicates.split()]


def query(target, goal, runtime, techniques, initial=None):
    return dict(source_foothold=IDS["X"], initial_actor=IDS["U"], authentication_context=IDS["X"],
                initial_state=initial or dict(usable_identity=[[IDS["U"], IDS["X"]]]),
                target=IDS[target], target_goal=dict(target=IDS[target], required_state=goal),
                runtime_facts=runtime, allowed_techniques=techniques,
                scenario_reference="AWG-R02/finite", budget=dict(max_paths=2000, max_steps=12, max_expansions=100000))


def key(tech, actor, source, target):
    return (tech, IDS.get(actor, actor), IDS.get(source, source), IDS.get(target, target))


@dataclass
class Case:
    number: int
    variant: str
    problem: Problem
    graph: EngineGraph
    query: dict
    bindings: dict
    expected: bool
    expected_C: float | None
    classification: str = "supported"
    notes: str = ""


def host_facts(actor="V", host="H2", group="G1"):
    return facts("host_admin_mapping", group, host) + facts("network_winrm_reachable service_winrm_running winrm_authentication_accepted endpoint_authorized admin_execution_context", actor, host)


def member_facts(actor, group):
    return facts("security_group membership_usable", actor, group)


def case1():
    edges = [("U","MemberOf","G1"),("U","MemberOf","G2"),("G1","MemberOf","G3"),("G2","MemberOf","G3"),("G3","MemberOf","G1"),("G3","AdminTo","H1")]
    actions = []
    bindings = {}
    for s, _, t in edges[:-1]:
        name = f"member_{s}_{t}"
        actions.append(a(name, ["usable_U"] + ([] if s == "U" else [f"member_U_{s}"]), [f"member_U_{t}"]))
        bindings[key("propagate_group_entitlement", "U", s, t)] = name
    actions.append(a("admin", ["usable_U", "member_U_G3"], ["admin_H1"], ["admin"]))
    bindings[key("obtain_admin_execution_on_host", "U", "G3", "H1")] = "admin"
    runtime = sum((member_facts("U", g) for g in ("G1","G2","G3")), []) + facts("admin_channel authentication_accepted", "U", "H1")
    p = Problem("membership-cycle-diamond", frozenset(["usable_U"]), frozenset(["admin_H1"]), tuple(actions), {"admin":1})
    q = query("H1", {"admin_control":[IDS["H1"]]}, runtime, ["propagate_group_entitlement","obtain_admin_execution_on_host"])
    return [Case(1,"cycle-diamond",p,graph(p.name,edges),q,bindings,True,1)]


def reset_case(force=False):
    edges = [("U", "ForceChangePassword" if force else "WriteDacl", "V"), ("V","MemberOf","G1"),("G1","GenericAll","H2")]
    runtime = facts("directory_write_allowed password_policy_accepts network_rpc_reachable", "U", "V") + facts("network_kdc_reachable authentication_accepted", "V", "X") + member_facts("V","G1") + host_facts()
    actions = []
    bindings = {}
    if not force:
        actions.append(a("grant",["usable_U"],["right_U_V"],["grant"]))
        bindings[key("grant_new_object_right","U","U","V")] = "grant"
    actions += [a("reset",["usable_U"] + ([] if force else ["right_U_V"]),["auth_V"] + ([] if force else ["reset_V"]),["reset"]),
                a("activate",["reset_V"],["usable_V"],["activate"]),
                a("member",["usable_V"],["member_V_G1"]),
                a("admin",["usable_V","member_V_G1"],["admin_H2"],["admin"])]
    tech = "reset_target_password" if force else "scenario_reset_password"
    bindings.update({key(tech,"U","U","V"):"reset",key("acquire_reset_identity","V","V","X"):"activate",key("propagate_group_entitlement","V","V","G1"):"member",key("scenario_winrm_admin","V","G1","H2"):"admin"})
    p = Problem("force-reset" if force else "write-dacl-reset", frozenset(["usable_U"]),frozenset(["admin_H2"]),tuple(actions),dict(grant=1,reset=2,activate=1,admin=1))
    q = query("H2",{"admin_control":[IDS["H2"]]},runtime,sorted({k[0] for k in bindings}))
    g = graph(p.name,edges)
    if not force:
        return [Case(2,"derived-right-chain",p,g,q,bindings,True,5)]
    out = [Case(3,"downstream-goal",p,g,q,bindings,False,None,"unsupported composition","Force reset produces authentication_control, not reset_password_control; no activation bridge in current vocabulary.")]
    marker = deepcopy(q); marker.update(target=IDS["V"],target_goal=dict(target=IDS["V"],required_state=dict(authentication_control=[IDS["V"]])))
    out.append(Case(3,"reset-marker",replace(p,goals=frozenset(["auth_V"])),g,marker,bindings,True,2))
    # Positive control: an explicitly declared reset credential CAN be activated.
    control = deepcopy(q); control["initial_state"]["reset_password_control"] = [IDS["V"]]
    out.append(Case(3,"declared-reset-credential-control",replace(p,initial=p.initial|{"reset_V"}),g,control,bindings,True,2,"positive control"))
    return out


def case4():
    edges = [("U","AdminTo","H1"),("H1","HasSession","V"),("V","MemberOf","G1"),("G1","GenericAll","H2")]
    runtime = facts("admin_channel authentication_accepted","U","H1") + facts("session_fresh session_present credential_accessible","H1","V") + member_facts("V","G1") + host_facts() + facts("secret_valid network_kdc_reachable authentication_accepted","V","X")
    actions = (a("admin-source",["usable_U"],["admin_H1"],["host"]),a("session-material",["admin_H1"],["material_V"],["dump"]),a("activate",["secret_V_X"],["usable_V"],["activate"]),a("member",["usable_V"],["member_V_G1"]),a("admin-goal",["usable_V","member_V_G1"],["admin_H2"],["admin"]))
    p = Problem("session-boundary",frozenset(["usable_U"]),frozenset(["admin_H2"]),actions,dict(host=1,dump=1,activate=1,admin=1))
    bindings = {key("obtain_admin_execution_on_host","U","U","H1"):"admin-source",key("recover_session_credential_material","U","H1","V"):"session-material",key("activate_recovered_identity","V","V","X"):"activate",key("propagate_group_entitlement","V","V","G1"):"member",key("scenario_winrm_admin","V","G1","H2"):"admin-goal"}
    bindings[key("recover_session_credential_material","V","H1","V")]="session-material"
    q = query("H2",{"admin_control":[IDS["H2"]]},runtime,sorted({k[0] for k in bindings}))
    g = graph(p.name,edges)
    out = [Case(4,"downstream-goal",p,g,q,bindings,False,None,"unsupported composition","HasSession does not declare a password or a recovery action; no automatic credential promotion is valid.")]
    marker = deepcopy(q);marker.update(target=IDS["V"],target_goal=dict(target=IDS["V"],required_state=dict(credential_material=[IDS["V"]])))
    out.append(Case(4,"material-marker",replace(p,goals=frozenset(["material_V"])),g,marker,bindings,True,2))
    control = deepcopy(q);control["initial_state"]["recovered_secret"] = [dict(owner=IDS["V"],context=IDS["X"],form="password",provenance=["synthetic://r02/explicit-password-positive-control"])]
    # Recovery/activation changes the scheduler's current actor; irrelevant source-host actions can be omitted.
    out.append(Case(4,"declared-password-control",replace(p,initial=p.initial|{"secret_V_X"}),g,control,bindings,True,2,"positive control"))
    return out


def credential_case(number, recovery=True):
    if number == 5:
        from scripts.research.asrep_inputs import inputs, X, V, C, G
        g,q = inputs();request="asrep_request";recover="recover_asrep_secret"
        initial=frozenset(["known_V","request_X_V"]);prereq=["known_V","request_X_V"]
        request_actor=X;request_source=X
    else:
        from scripts.research.kerberoasting_probe import synthetic, X, U, V, C, G
        g,q=synthetic();request="kerberoast_request";recover="recover_ticket_secret"
        initial=frozenset(["usable_U"]);prereq=["usable_U"]
        request_actor=U;request_source=U
    # Only change the named recovery guard; activation remains a separate action.
    selected=[f for f in q["assumptions"] if f["predicate"]=="recovery_success"]
    if recovery is not True:
        q["assumptions"]=[f for f in q["assumptions"] if f["predicate"]!="recovery_success"]
        if recovery is False:
            q["runtime_facts"]=[{**f,"value":False} for f in selected]
    actions=(a("request",prereq,["material_V_X"],["request"]),a("recover",["material_V_X"],["secret_V_X"],["recover"],[("recovery_success",recovery)]),a("activate",["secret_V_X"],["usable_V"],["activate"]),a("member",["usable_V"],["member_V_G"]),a("admin",["usable_V","member_V_G"],["admin_C"],["admin"]))
    p=Problem(f"credential-{number}-{recovery}",initial,frozenset(["admin_C"]),actions,dict(request=1,recover=3,activate=1,admin=1))
    bindings={(request,request_actor,request_source,V):"request",(recover,request_actor,request_source,V):"recover",("activate_recovered_identity",V,V,X):"activate",("propagate_group_entitlement",V,V,G):"member",("scenario_winrm_admin",V,G,C):"admin"}
    return Case(number,str(recovery).lower(),p,g,q,bindings,recovery is True,6 if recovery is True else None)


def rbcd_case(number=7, variant="full", gate=None, value=True):
    from scripts.research.rbcd_inputs import inputs, U_R, M, C_R, P, X
    g,q=inputs()
    initial={"usable_R","known_M","known_P"}
    guards={"acquire":[],"prepare":[],"configure":[],"delegate":[],"admin":[]}
    if gate:
        stage={"effective_reset_right":"acquire","secret_valid":"prepare","effective_descriptor_write":"configure","delegation_policy_allows":"delegate","s4u_request_accepted":"delegate","admin_execution_context":"admin"}[gate]
        guards[stage].append((gate,value))
        selected=[f for f in q["assumptions"] if f["predicate"]==gate]
        assert selected
        q["assumptions"]=[f for f in q["assumptions"] if f["predicate"]!=gate]
        if value is False:
            q["runtime_facts"]=[{**f,"value":False} for f in selected]
    actions=[a("acquire",["usable_R"],["secret_M_B"],["acquire"],guards["acquire"]),a("prepare",["secret_M_B"],["service_M_B"],["prepare"],guards["prepare"]),a("configure",["usable_R","known_M"],["descriptor_B"],["configure"],guards["configure"]),a("delegate",["service_M_B","descriptor_B","known_P"],["delegated_B"],["delegate"],guards["delegate"]),a("admin",["delegated_B"],["admin_C"],["admin"],guards["admin"])]
    if variant=="reuse-service":
        artifact=DelegationArtifact(DelegationBinding(**q["rbcd_bindings"][0]),("synthetic://r02/reuse-service",))
        q["initial_state"]["controlled_service"]=[asdict(artifact)];initial.add("service_M_B")
    if variant in {"missing-service","missing-descriptor"}:
        # Isolate each side of the AND: do not permit regenerating the missing side.
        name="prepare" if variant=="missing-service" else "configure"
        actions=[ac for ac in actions if ac.name!=name]
        q["allowed_techniques"]=[t for t in q["allowed_techniques"] if t!=("rbcd_prepare_service" if name=="prepare" else "rbcd_configure_descriptor")]
    if variant in {"wrong-service-binding","wrong-runtime-context"}:
        b=DelegationBinding(**q["rbcd_bindings"][0]);foreign=replace(b,authentication_context=C_R)
        q["initial_state"]["controlled_service"]=[asdict(DelegationArtifact(foreign,("synthetic://r02/foreign-context",)))]
        initial.add("service_M_OTHER_CONTEXT")
        # Disable preparation to prevent a legitimate new matching artifact.
        actions=[ac for ac in actions if ac.name!="prepare"]
        q["allowed_techniques"]=[t for t in q["allowed_techniques"] if t!="rbcd_prepare_service"]
        if variant=="wrong-runtime-context":
            q["authentication_context"]=C_R
            actions=[replace(ac,guards=ac.guards+(("binding_context_matches",False),)) for ac in actions]
    p=Problem(f"rbcd-{variant}",frozenset(initial),frozenset(["admin_C"]),tuple(actions),dict(acquire=2,prepare=3,configure=2,delegate=1,admin=1))
    binding={("rbcd_acquire_secret",U_R,U_R,M):"acquire",("rbcd_prepare_service",U_R,U_R,M):"prepare",("rbcd_configure_descriptor",U_R,U_R,C_R):"configure",("rbcd_delegate_service",U_R,U_R,C_R):"delegate",("rbcd_service_admin",U_R,U_R,C_R):"admin"}
    expected=(variant in {"full","reuse-service"}) and (gate is None or value is True)
    return Case(number,variant if not gate else f"{gate}-{value}",p,g,q,binding,expected,(4 if variant=="reuse-service" else 9) if expected else None)


def case9():
    # Public typed multi-goal, two already usable actors in ONE context. Each
    # explicit request is applicable under the evaluator; no invented action.
    edges=[("U","AdminTo","H1"),("V","AdminTo","H2"),("U","AdminTo","H3")]
    runtime=sum((facts("admin_channel authentication_accepted",u,h) for u,_,h in edges),[])
    actions=tuple(a(f"admin-{h}",[f"usable_{u}"],[f"admin_{h}"],[h]) for u,_,h in edges)
    p=Problem("usable-actors-multi-goal",frozenset(["usable_U","usable_V"]),frozenset(["admin_H1","admin_H2","admin_H3"]),actions,dict(H1=1,H2=1,H3=1))
    q=query("H3",{"admin_control":[IDS[h] for h in ("H1","H2","H3")]},runtime,["obtain_admin_execution_on_host"],initial={"usable_identity":[[IDS[u],IDS["X"]] for u in ("U","V")]})
    bindings={key("obtain_admin_execution_on_host",u,u,h):f"admin-{h}" for u,_,h in edges}
    return [Case(9,"two-usable-actors-return",p,graph(p.name,edges),q,bindings,True,3,"candidate completeness probe","Explicit replay order U:H1 -> V:H2 -> U:H3 tests returning to an already usable actor.")]


# Explicitly authored stage/gate instances; not read from the executable catalog.
RBCD_RUNTIME = {
    "acquire": ("effective_reset_right", "directory_write_allowed", "password_policy_accepts"),
    "prepare": ("secret_valid", "key_derivation_accepted", "key_encryption_compatible", "service_authentication_accepted", "network_kdc_reachable"),
    "configure": ("effective_descriptor_write", "directory_write_allowed"),
    "delegate": ("target_spn_binding", "delegation_policy_allows", "network_kdc_reachable", "s4u_request_accepted"),
    "admin": ("target_spn_binding", "network_winrm_reachable", "service_winrm_running", "endpoint_authorized", "winrm_authentication_accepted", "admin_execution_context"),
}


def rbcd_runtime_probe(stage, gate, value):
    from scripts.research.rbcd_inputs import U_R, M, C_R, P
    c=rbcd_case(8)
    subject=P if stage=="admin" else U_R
    target=M if stage in {"acquire","prepare"} else C_R
    selected=[f for f in c.query["assumptions"] if (f["predicate"],f["subject"],f["target"])==(gate,subject,target)]
    assert len(selected)==1,(stage,gate,selected)
    c.query["assumptions"]=[f for f in c.query["assumptions"] if f not in selected]
    if value is False:
        c.query["runtime_facts"]=[{**f,"value":False} for f in selected]
    actions=tuple(replace(ac,guards=ac.guards+((gate,value),)) if ac.name==stage else ac for ac in c.problem.actions)
    c.problem=replace(c.problem,name=f"runtime-{stage}-{gate}-{value}",actions=actions)
    c.variant=c.problem.name;c.expected=False;c.expected_C=None
    c.notes=f"Only ({gate}, {subject}, {target}) changed to {value}; exact typed binding metadata retained."
    return c


def rbcd_static_probe(variant):
    from scripts.research.rbcd_inputs import U_R, M, C_R, P
    from src.parser.snapshot_facts import FactEvidence, SnapshotFact, SnapshotFacts, serialize_snapshot
    c=rbcd_case(8);c.variant=variant;c.expected=False;c.expected_C=None
    initial=set(c.problem.initial);actions=list(c.problem.actions)
    stage=None
    if variant in {"missing-known-M","missing-known-P"}:
        owner=M if variant.endswith("M") else P
        c.query["initial_state"]["known_identity"].remove(owner)
        initial.remove("known_M" if owner==M else "known_P")
    elif variant=="missing-usable-controller":
        c.query["initial_state"].update(usable_identity=[],control=[U_R]);initial.remove("usable_R")
    elif variant in {"missing-exact-reset-right","missing-exact-descriptor-right"}:
        target=M if "reset" in variant else C_R
        c.query["withheld_relationships"]=[[e["source"],e["kind"],e["target"]] for e in c.graph.to_canonical()["edges"] if e["source"]==U_R and e["target"]==target]
        stage="acquire" if target==M else "configure"
    elif variant.startswith("spn-"):
        name="service_principal_names" if "values" in variant else "has_spn"
        unknown=variant.endswith("unknown")
        value=None if unknown else () if name=="service_principal_names" else False
        old=c.graph.snapshot_facts.lookup(M,name)
        evidence=() if unknown else tuple(FactEvidence(json.dumps(value),e.provenance) for e in old.evidence)
        sf=SnapshotFact(M,name,"unknown" if unknown else "known",value,evidence)
        all_facts=tuple(sf if (f.subject,f.name)==(M,name) else f for f in c.graph.snapshot_facts.facts)
        snapshot=replace(c.graph.snapshot_facts,facts=all_facts)
        c.graph=EngineGraph.from_snapshot(serialize_snapshot(c.graph.to_canonical(),snapshot))
        stage="prepare"
        actions=[replace(ac,guards=ac.guards+((name,None if unknown else False),)) if ac.name==stage else ac for ac in actions]
        stage=None
    if stage:
        actions=[replace(ac,guards=ac.guards+((variant,False),)) if ac.name==stage else ac for ac in actions]
    c.problem=replace(c.problem,name=variant,initial=frozenset(initial),actions=tuple(actions))
    return c


def case10():
    edges=[("U","AdminTo","H1"),("U","MemberOf","G1"),("G1","AdminTo","H1"),("H1","HasSession","V")]
    runtime=facts("admin_channel authentication_accepted","U","H1")+member_facts("U","G1")+facts("session_fresh session_present credential_accessible","H1","V")
    # A cheaper prefix A=2 loses against B=5 because the suffix reuses B's work.
    actions=(a("direct",["usable_U"],["admin_H1"],["A"]),a("member",["usable_U"],["member_U_G1"]),a("inherited",["usable_U","member_U_G1"],["admin_H1"],["B"]),a("material",["admin_H1"],["material_V"],["B"]))
    p=Problem("shared-work-prefix",frozenset(["usable_U"]),frozenset(["material_V"]),actions,dict(A=2,B=5))
    bindings={key("obtain_admin_execution_on_host","U","U","H1"):"direct",key("propagate_group_entitlement","U","U","G1"):"member",key("obtain_admin_execution_on_host","U","G1","H1"):"inherited",key("recover_session_credential_material","U","H1","V"):"material"}
    q=query("V",{"credential_material":[IDS["V"]]},runtime,sorted({k[0] for k in bindings}))
    return [Case(10,"shared-work-prefix",p,graph(p.name,edges),q,bindings,True,5,"synthetic cost probe","Manual union-work ledger, not calibrated effort. AND-OR first support is deliberately not a C optimizer.")]


def case11(value):
    g=graph(f"unknown-{value}",[("U","AdminTo","H1")])
    runtime=facts("authentication_accepted","U","H1")+([] if value is None else [fact("admin_channel","U","H1",value)])
    p=Problem(f"guard-{value}",frozenset(["usable_U"]),frozenset(["admin_H1"]),(a("admin",["usable_U"],["admin_H1"],["admin"],[("admin_channel",value)]),),dict(admin=1))
    q=query("H1",{"admin_control":[IDS["H1"]]},runtime,["obtain_admin_execution_on_host"])
    if value is False:
        for entry in q["runtime_facts"]:
            if entry["predicate"]=="admin_channel":
                entry["origin"]="observed_evidence"
        q["assumptions"]=[fact("admin_channel","U","H1",True)]
    return Case(11,str(value).lower(),p,g,q,{key("obtain_admin_execution_on_host","U","U","H1"):"admin"},value is True,1 if value is True else None)


def case12(context="X", owner="V", material=False):
    g=graph("isolation",[("V","MemberOf","G1"),("G1","GenericAll","H2")],extra=["Y","W"])
    field="asrep_material" if material else "recovered_secret"
    initial={field:[dict(owner=IDS[owner],context=IDS[context],form="kerberos_asrep" if material else "password",provenance=["synthetic://r02/isolation"])]}
    runtime=facts("secret_valid network_kdc_reachable authentication_accepted","V","X")+member_facts("V","G1")+host_facts()
    artifact=f"{'material' if material else 'secret'}_{owner}_{context}"
    p=Problem(f"isolated-{artifact}",frozenset([artifact]),frozenset(["admin_H2"]),(a("activate",["secret_V_X"],["usable_V"],["activate"]),a("member",["usable_V"],["member_V_G1"]),a("admin",["usable_V","member_V_G1"],["admin_H2"],["admin"])),dict(activate=1,admin=1))
    q=query("H2",{"admin_control":[IDS["H2"]]},runtime,["activate_recovered_identity","propagate_group_entitlement","scenario_winrm_admin"],initial=initial)
    q["initial_actor"]=IDS["X"]
    q["initial_state"]["control"]=[IDS["X"]]
    bindings={key("activate_recovered_identity","V","V","X"):"activate",key("propagate_group_entitlement","V","V","G1"):"member",key("scenario_winrm_admin","V","G1","H2"):"admin"}
    expected=context=="X" and owner=="V" and not material
    return Case(12,f"{owner}-{context}-{'material' if material else 'password'}",p,g,q,bindings,expected,2 if expected else None)


def cases():
    out=case1()+reset_case()+reset_case(True)+case4()
    out += [credential_case(n,v) for n in (5,6) for v in (True,False,None)]
    out += [rbcd_case(),rbcd_case(7,"reuse-service")]
    out += [rbcd_case(8,v) for v in ("missing-service","missing-descriptor","wrong-service-binding","wrong-runtime-context")]
    out += [rbcd_runtime_probe(stage,gate,v) for stage,gates in RBCD_RUNTIME.items() for gate in gates for v in (False,None)]
    out += [rbcd_static_probe(v) for v in ("missing-known-M","missing-known-P","missing-usable-controller","missing-exact-reset-right","missing-exact-descriptor-right","spn-flag-false","spn-flag-unknown","spn-values-empty","spn-values-unknown")]
    out += case9()+case10()+[case11(v) for v in (True,False,None)]
    out += [case12(),case12("Y"),case12("X","W"),case12("X","V",True)]
    return out
