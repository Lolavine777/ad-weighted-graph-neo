"""F0 API/CLI transport and truncation controls at the exact baseline SHA."""
from copy import deepcopy
import hashlib
import json
from pathlib import Path
import subprocess
import sys

from cases import BASE, ROOT
from src.engine.graph import EngineGraph
from src.engine.query import run_attack_query
from src.engine.query_cli import wire


def main():
    query=json.loads((BASE/'tests/fixtures/query_cli/two-routes-query.json').read_text())
    graph=EngineGraph.from_canonical((BASE/'tests/fixtures/attack_scenarios/graphs/two-routes.json').read_text())
    output={'transport':[]}
    for name,extra in [('omitted',{}),('null-graph',{'graph':None}),('null-catalog',{'catalog':None}),('both-null',{'graph':None,'catalog':None})]:
        q={**query,**extra}
        api=run_attack_query(q,graph)
        file=ROOT/f'evidence/f0-query-{name}.json';file.write_text(json.dumps(q,indent=2)+'\n')
        out=ROOT/f'evidence/f0-cli-{name}.json'
        cmd=[sys.executable,'-m','src.engine.query_cli','--query',str(file),'--graph','tests/fixtures/attack_scenarios/graphs/two-routes.json','--label','synthetic','--output',str(out)]
        proc=subprocess.run(cmd,cwd=BASE,text=True,capture_output=True)
        package=json.loads(out.read_text()) if out.exists() else None
        output['transport'].append(dict(variant=name,API_paths=len(api.paths),API_complete=api.complete,CLI_exit_code=proc.returncode,
                                        stderr=proc.stderr,CLI_package=package))
        assert len(api.paths)==3 and api.complete
        assert proc.returncode==(0 if name=='omitted' else 1)
    q=deepcopy(query)
    q['ranking_query']=json.loads((BASE/'docs/research/ratings/week4/synthetic-a2-e.json').read_text())['query']
    q['top_k']=1;q['budget']['max_expansions']=1
    truncated=run_attack_query(q,graph)
    assert not truncated.complete and not truncated.top_k_result['guarantee']['is_k_best_proven']
    output['truncation_control']=dict(paths=len(truncated.paths),complete=truncated.complete,truncation_reason=truncated.truncation_reason,
                                       min_effort=truncated.min_effort,top_k=truncated.top_k_result)
    tree=json.loads((ROOT/'evidence/upstream-tree.json').read_text())
    entries={e['path']:e for e in tree['tree'] if e['type']=='blob'}
    subset=ROOT/'evidence/audited-source-files.json'
    if subset.exists():
        audited={item['path'] for item in json.loads(subset.read_text())}
        entries={p:e for p,e in entries.items() if p in audited}
    verified=[]
    for path,e in entries.items():
        file=BASE/path
        if file.is_file():
            data=file.read_bytes();blob=hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()
            assert blob==e['sha'],path
            verified.append(dict(path=path,git_blob=blob,sha256=hashlib.sha256(data).hexdigest(),bytes=len(data)))
    output['verified_source_files']=verified
    output['git_status']=subprocess.check_output(['git','status','--porcelain'],cwd=BASE,text=True)
    assert output['git_status']==''
    manifest=json.loads((BASE/'data/samples/manifests/seamless-raw-v1.json').read_text())
    output['raw_manifest']=manifest
    output['raw_available_in_materialized_checkout']={f['relative_path']:(BASE/f['relative_path']).exists() for f in manifest['files']}
    (ROOT/'evidence/f0-probes.json').write_text(json.dumps(wire(output),ensure_ascii=False,indent=2)+'\n')
    print(json.dumps(dict(transport=[{k:v for k,v in r.items() if k!='CLI_package'} for r in output['transport']],truncation=output['truncation_control']['top_k']['guarantee'],verified_blobs=len(verified)),indent=2))


if __name__=='__main__':main()
