"""F1.10 native rating check: literal A=2, B=(4+1), suffix reuses B.

Both P and I deliberately unrated. The numbers are finite-test data, not expert
estimates or claims about real AD effort. Independent oracle cost is not imported
from the native assessor. B is split only to respect AWG's 0..4/unit rubric.
"""
from copy import deepcopy
from dataclasses import replace
import json

from cases import ROOT, case10
from oracle import exhaustive
from src.engine.query import run_attack_query
from src.engine.query_cli import wire


def inputs():
    c=case10()[0]
    p=c.problem
    actions=tuple(replace(a,work=frozenset({'B-prep','B-auth'}) if 'B' in a.work else a.work) for a in p.actions)
    p=replace(p,actions=actions,costs={'A':2,'B-prep':4,'B-auth':1})
    request_by_name={v:k for k,v in c.bindings.items()}
    predicate_names=set(p.initial)|set(p.goals)
    for a in p.actions:
        predicate_names.update(a.requires|a.adds)
    target=c.query['target']
    query_id='r02-shared-work-literal'
    ledger={
        'predicate_layers':{f:3 for f in sorted(predicate_names)},
        'observed_facts':[], 'false_facts':[], 'unknown_facts':[],
        'assumed_facts':[dict(predicate=f,layer=3,truth_value=f in p.initial,rationale='Finite synthetic initial truth assignment; not observed telemetry',provenance_reference='synthetic://r02/f1-10') for f in sorted(predicate_names)]}
    actions=[]
    for a in p.actions:
        tech,actor,source,goal=request_by_name[a.name]
        actions.append(dict(action_id=a.name,technique=tech,technique_name=tech,actor_id=actor,target_id=goal,
                            requires=sorted(a.requires),adds=sorted(a.adds),referenced_work_unit_ids=sorted(a.work),is_passive_closure=not a.work))
    units={}
    for name,cost in p.costs.items():
        t1,t2={1:(1,2),2:(2,2),4:(3,3)}[cost]
        units[name]=dict(alias=name,rating_status='rated',overlap_state='independent',computed_cost=cost,effort_cost=cost,
                         rubric_scores=dict(t1=t1,t2=t2,formula='base',computed_cost=cost),summary='Synthetic reusable work identity '+name,
                         technical_source='synthetic://r02/f1-10',applicable_queries=[query_id],missing_basis_reasons=[])
    packet=dict(query_metadata=dict(query_id=query_id,version='1.0.0',scenario_id=c.query['scenario_reference'],scenario_version='1.0.0',
                                    snapshot_id=c.graph.metadata['snapshot_id'],evaluation_mode='scenario',work_boundary='r02-synthetic-reusable-work',
                                    foothold_node_id=c.query['initial_actor'],horizon='fixed-snapshot-window',active_work_budget=10,
                                    target_goal=dict(goal_id='material-V',target_asset_id=target,success_event='material-V',required_predicates=sorted(p.goals))),
                facts_ledger=ledger,bound_actions=actions,work_units_ledger=units,conditional_bounds_table=[],
                target_impact_assessments={target:dict(target_asset_id=target,success_event='material-V',rating_status='unrated',consequence_rating=None,
                                                    business_rationale=None,affected_business_services=[],missing_basis_reasons=['no_business_impact_basis'])})
    q=deepcopy(c.query)
    q.update(ranking_query=packet,action_bindings=[[list(k),v] for k,v in c.bindings.items()],top_k=10)
    return c.graph,q,p


def main():
    graph,q,p=inputs()
    oracle=exhaustive(p)
    result=run_attack_query(q,graph)
    output=dict(oracle=oracle,min_effort=result.min_effort,top_k=result.top_k_result,binding_diagnostics=result.binding_diagnostics,
                ranking_result=result.ranking_result,query=q,graph=graph.to_canonical())
    (ROOT/'evidence/f1-shared-work-native-rating.json').write_text(json.dumps(wire(output),ensure_ascii=False,indent=2)+'\n')
    assert result.min_effort['minimum_effort_value']==oracle['min_C']==5
    assert result.top_k_result['guarantee']['is_k_best_proven']
    efforts=[p['effort'] for p in result.top_k_result['programs']]
    assert 5 in efforts and 7 in efforts
    print(json.dumps(dict(oracle_min_C=oracle['min_C'],native_min_C=result.min_effort['minimum_effort_value'],efforts=efforts,guarantee=result.top_k_result['guarantee']),indent=2))


if __name__=='__main__':
    main()
