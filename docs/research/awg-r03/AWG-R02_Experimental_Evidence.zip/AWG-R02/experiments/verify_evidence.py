"""Consistency checks on the executed evidence, not a replacement AD oracle."""
import ast
from datetime import datetime, UTC
import hashlib
import json
from pathlib import Path
import subprocess
import xml.etree.ElementTree as ET

ROOT=Path(__file__).resolve().parents[1]
E=ROOT/'evidence'
checks={}
def require(name,value):
    checks[name]=bool(value)
    assert value,name

f0=ET.parse(E/'f0-complete.xml').getroot()
suites=f0.findall('testsuite') if f0.tag=='testsuites' else [f0]
require('focused_suite_310_passed',sum(int(s.attrib['tests']) for s in suites)==310 and all(int(s.attrib['failures'])==0 and int(s.attrib['errors'])==0 and int(s.attrib['skipped'])==0 for s in suites))
f1=json.loads((E/'f1-results.json').read_text())
require('78_variants_12_groups',len(f1['cases'])==78 and {c['case'] for c in f1['cases']}==set(range(1,13)))
require('only_expected_actor_composition_mismatch',[(c['case'],c['variant']) for c in f1['cases'] if not all(c['comparison'].values())]==[(9,'two-usable-actors-return')])
require('67_native_witnesses_independent_valid_and_replayed',sum(c['native']['path_count'] for c in f1['cases'])==67 and all(p['oracle_valid'] and p['replay_valid'] for c in f1['cases'] for p in c['native']['paths']))
require('and_or_matches_all_confirmed_reachability',all(c['and_or']['reachable']==c['oracle']['reachable'] and c['and_or']['witness_valid'] for c in f1['cases']))
require('conditional_graph_executed_23_otherwise_explicit_unsupported',sum(c['conditional_graph']['status']=='executed' for c in f1['cases'])==23)
current_inputs=set()
for c in f1['cases']:
    p=ROOT/c['input_file'];current_inputs.add(p)
    require('input_hash_'+p.name,hashlib.sha256(p.read_bytes()).hexdigest()==c['input_sha256'])
# Remove only superseded generated input files, retained from developing probes.
for p in (E/'f1-inputs').glob('*.json'):
    if p not in current_inputs:p.unlink()
require('exactly_78_current_input_files',len(list((E/'f1-inputs').glob('*.json')))==78)
cost=json.loads((E/'f1-shared-work-native-rating.json').read_text())
require('native_shared_work_minimum_5',cost['oracle']['min_C']==cost['min_effort']['minimum_effort_value']==5 and cost['top_k']['guarantee']['is_k_best_proven'])
require('native_cost_probe_P_I_unrated',all(p['likelihood_interval'] is None and p['impact'] is None for p in cost['top_k']['programs']))
f2=json.loads((E/'f2-results.json').read_text())
require('four_profile_pipeline_fixtures',len(f2['fixtures'])==4)
for f in f2['fixtures']:
    rows=[m['first_query'] for m in f['modes'].values()]+[r for m in f['modes'].values() for r in m['subsequent_queries']]
    require('cache_exact_output_'+f['name'],len(rows)==8 and len({r['digest'] for r in rows})==1)
    for r in rows:
        total=sum(r[k] for k in ('graph_seconds','materialize_seconds','search_seconds','replay_seconds','rating_exclusive_seconds','serialization_seconds'))
        require('phase_accounting_'+f['name']+'_'+str(rows.index(r)),abs(total-r['total_seconds'])<1e-7)
for n,rs in f2['merge_probes'].items():
    require('merge_same_terminal_sets_'+n,rs['stock']['states_hash']==rs['merge']['states_hash'] and rs['stock']['unique_goal_membership_sets']==2**int(n)-1)
    require('merge_discloses_loss_of_ordered_programs_'+n,not rs['merge']['all_ordered_programs_preserved'])
for name in ('oracle.py','alternatives.py'):
    tree=ast.parse((ROOT/'experiments'/name).read_text())
    imports=[(n.module if isinstance(n,ast.ImportFrom) else alias.name) for n in ast.walk(tree) if isinstance(n,(ast.Import,ast.ImportFrom)) for alias in (n.names if isinstance(n,ast.Import) else [None])]
    require('independent_imports_'+name,all(not n.startswith(('src','scripts','cases')) for n in imports))
tree=json.loads((E/'upstream-tree.json').read_text())
audited_paths={item['path'] for item in json.loads((E/'audited-source-files.json').read_text())}
source_count=0
for item in tree['tree']:
    p=ROOT/'baseline'/item['path']
    if item['type']=='blob' and item['path'] in audited_paths:
        require('audited_source_present_'+item['path'],p.is_file())
        data=p.read_bytes()
        require('unchanged_source_'+item['path'],hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()==item['sha'])
        source_count+=1
require('126_upstream_files_byte_identical',source_count==126)
require('no_baseline_changes',subprocess.check_output(['git','status','--porcelain'],cwd=ROOT/'baseline',text=True)=='')
result=dict(verified_at=datetime.now(UTC).isoformat(),checks=checks,passed=sum(checks.values()),failed=sum(not v for v in checks.values()),
            note='Evidence consistency only; not extra product/AD tests. Timing numbers remain environment dependent.')
(E/'final-qa.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(dict(passed=result['passed'],failed=result['failed'],source_files=source_count),indent=2))
