#!/usr/bin/env bash
set -euo pipefail
r02_root="$(cd -- "$(dirname -- "$0")/.." && pwd)"
r02_python="$r02_root/.venv/bin/python"
cd "$r02_root/baseline"
exec "$r02_python" -m pytest -q \
  tests/test_attack_semantics_transitions.py tests/test_engine.py \
  tests/test_rbcd.py tests/test_asrep.py tests/test_kerberoasting.py \
  tests/test_top_k_search.py tests/test_exploration.py \
  tests/test_week4_min_effort_search.py tests/test_graph_lineage.py \
  --junitxml="$r02_root/evidence/f0-complete.xml"
