"""Run F1; produce machine-readable input, outcomes, witnesses and diagnostics."""
from collections import Counter
from dataclasses import asdict
import hashlib
import json
import platform
import sys
import time

from alternatives import and_or, conditional_graph
from cases import BASE, IDS, ROOT, cases, key
from oracle import Action, Problem, all_goal_traces, exhaustive
from src.engine.query import materialize_query
from src.engine.query_cli import wire
from src.engine.semantics import AttackState, TransitionRequest, apply_transition, evaluate
from src.engine.semantics.credentials import replay_path
from src.engine.semantics.evaluator import PreparedSemanticGraph
from src.engine.semantics.transitions import Status


def dump(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2, sort_keys=True) + "\n")


def oracle_self_check():
    # Literal AND truth table and cyclic proof: no AWG inputs involved.
    truth_table = []
    for f in (False, True):
        for g in (False, True):
            p=Problem("AND",frozenset((['f'] if f else [])+(['g'] if g else [])),frozenset(['z']),
                      (Action('join',frozenset(['f','g']),frozenset(['z'])),))
            expected=f and g
            for solver in (exhaustive,and_or):
                assert solver(p)['reachable'] is expected
            truth_table.append(dict(f=f,g=g,z=expected))
    p=Problem('cycle',frozenset(),frozenset(['x']),(
        Action('a',frozenset(['x']),frozenset(['y'])),Action('b',frozenset(['y']),frozenset(['x']))))
    assert not exhaustive(p)['reachable'] and not and_or(p)['reachable']
    return {"AND_truth_table":truth_table,"unseeded_cycle_reachable":False}


def main():
    result={"experiment":"AWG-R02/F1", "commit":"340e8e526e1e693d4c4b55635c459985eb08fa49",
            "python":platform.python_version(),"oracle_self_checks":oracle_self_check(),"cases":[]}
    for case in cases():
        p=case.problem
        oracle=exhaustive(p)
        assert (oracle['reachable'],oracle['min_C'])==(case.expected,case.expected_C),(case.number,case.variant,oracle)
        alternative=and_or(p);conditional=conditional_graph(p)
        assert alternative['reachable']==oracle['reachable']
        assert alternative['witness_valid']
        if conditional['status']=='executed':
            assert conditional['reachable']==oracle['reachable'] and conditional['witness_valid']
            if conditional.get('min_C') is not None:
                assert conditional['min_C']==oracle['min_C']
        inputs=dict(problem=asdict(p),query=case.query,graph=case.graph.to_canonical(),snapshot_facts=wire(case.graph.snapshot_facts),
                    request_bindings=[dict(request=list(k),action=v) for k,v in sorted(case.bindings.items())],
                    literal_expected_reachable=case.expected,literal_expected_C=case.expected_C)
        input_path=ROOT / f"evidence/f1-inputs/{case.number:02d}-{case.variant}.json"
        dump(input_path,wire(inputs))
        original=json.dumps(wire(inputs),sort_keys=True)
        t=time.perf_counter();m=materialize_query(case.query,case.graph);materialize_seconds=time.perf_counter()-t
        t=time.perf_counter();native=m.search(case.graph);search_seconds=time.perf_counter()-t
        paths=[]
        for path in native.paths:
            requests=[step.result.request for step in path.transition_history]
            trace=[case.bindings.get((r.technique_id,r.actor,r.source,r.target),'UNMODELLED:'+repr(r)) for r in requests]
            valid,diagnostic=p.check(trace)
            replayed=replay_path(path,case.graph,m.catalog)==path.final_state if requests else m.is_success_state(path.final_state)
            assert replayed
            paths.append(dict(trace=trace,oracle_valid=valid,diagnostic=diagnostic if not valid else None,
                              replay_valid=replayed,C=p.cost(trace) if valid else None,
                              requests=wire(requests),final_state=wire(path.final_state)))
        nonapplicable=[a for a in native.attempts if a.status is not Status.APPLICABLE]
        assert all(a.additions==AttackState() for a in nonapplicable)
        assert json.dumps(wire(inputs),sort_keys=True)==original
        valid_costs=[p['C'] for p in paths if p['oracle_valid']]
        minimum=min(valid_costs) if valid_costs else None
        comparison=dict(reachability_matches=bool(native.paths)==oracle['reachable'],
                        witnesses_valid=all(p['oracle_valid'] for p in paths),
                        min_C_matches=minimum==oracle['min_C'],
                        all_nonapplicable_have_no_effects=True,
                        coverage_complete=native.complete)
        row=dict(case=case.number,variant=case.variant,scope=case.classification,notes=case.notes,
                 oracle=oracle,conditional_graph=conditional,and_or=alternative,
                 native=dict(reachable=bool(native.paths),paths=paths,path_count=len(paths),minimum_C_under_independent_ledger=minimum,
                             expansions=native.expansions,complete=native.complete,truncation_reason=native.truncation_reason,
                             attempt_status_counts=dict(Counter(a.status.value for a in native.attempts)),
                             attempts=[dict(request=wire(a.request),status=a.status.value,failed=list(a.failed),unknown=list(a.unknown)) for a in native.attempts],
                             materialize_seconds=materialize_seconds,search_seconds=search_seconds),
                 comparison=comparison,input_file=str(input_path.relative_to(ROOT)),input_sha256=hashlib.sha256(input_path.read_bytes()).hexdigest())
        if case.number==1:
            assert all(not (set(IDS[g] for g in ('G1','G2','G3')) & path.final_state.control) for path in native.paths)
            row['group_identity_compromise']=False
        if case.number==6:
            # Pure topology reachability, independent of the semantic oracle.
            import networkx as nx
            from scripts.research.kerberoasting_probe import U,V
            topology=nx.DiGraph((e['source'],e['target']) for e in case.graph.to_canonical()['edges'])
            topology.add_nodes_from(n['id'] for n in case.graph.to_canonical()['nodes'])
            row['structural_route_to_service_identity']=nx.has_path(topology,U,V)
            assert not row['structural_route_to_service_identity']
        if case.number==7 and case.variant=='full':
            expected_orders=[list(t) for t in all_goal_traces(p)]
            actual_orders=sorted(v['trace'] for v in paths)
            assert expected_orders==actual_orders and len(actual_orders)==3
            row['three_orders_match']=True
        if case.number==9:
            # Additional checker: an explicit U -> V -> U schedule consists only
            # of existing catalog actions, evaluated against accumulated state.
            prepared=PreparedSemanticGraph(case.graph.to_canonical(),snapshot_facts=case.graph.snapshot_facts)
            state=m.initial_attack_state
            replay=[]
            for actor,host in [('U','H1'),('V','H2'),('U','H3')]:
                r=TransitionRequest('obtain_admin_execution_on_host',IDS[actor],IDS[actor],IDS[host])
                step=evaluate(prepared,state,r,m.runtime_context,m.catalog)
                replay.append(dict(request=wire(r),status=step.status.value,failed=list(step.failed),unknown=list(step.unknown)))
                assert step.status is Status.APPLICABLE
                state=apply_transition(state,step)
            assert m.is_success_state(state)
            row['manual_evaluator_replay']=dict(steps=replay,goal=True,final_state=wire(state),
                caveat='Public supported multi-capability goal, two initially usable identities in one scope. Exact R01 novel-right-after-switch case is not expressible with existing actor-self mutation recipes; not claimed reproduced.')
        if case.number==11:
            status={"true":Status.APPLICABLE,"false":Status.BLOCKED,"none":Status.INDETERMINATE}[case.variant]
            assert len(native.attempts)==1 and native.attempts[0].status is status
            if case.variant=="false":
                assert m.rejected_assumptions
                row['known_false_veto_rejected_optimism']=wire(m.rejected_assumptions)
        result['cases'].append(row)
        dump(ROOT/'evidence/f1-results.json',result)
        print(json.dumps(dict(case=case.number,variant=case.variant,oracle=oracle['reachable'],native=bool(native.paths),paths=len(paths),C=minimum,complete=native.complete,comparison=comparison)),flush=True)
    failures=[dict(case=c['case'],variant=c['variant'],comparison=c['comparison']) for c in result['cases'] if not all(c['comparison'].values())]
    result['summary']=dict(variant_count=len(result['cases']),group_count=len({c['case'] for c in result['cases']}),mismatches=failures,
                           alternatives_scope='Identical manually grounded finite actions; no production grounding, no calibrated C/P/I, AND-OR is reachability only.')
    dump(ROOT/'evidence/f1-results.json',result)


if __name__=='__main__':
    main()
