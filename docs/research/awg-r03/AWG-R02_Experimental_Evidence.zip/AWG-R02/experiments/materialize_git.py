"""Rebuild a sparse, local audit checkout from SHA-verified GitHub API objects."""
import hashlib
import json
from pathlib import Path
import subprocess
import zlib

ROOT = Path(__file__).resolve().parents[1]
repo = ROOT / "baseline"
tree = json.loads((ROOT / "evidence/upstream-tree.json").read_text())
commit = json.loads((ROOT / "evidence/upstream-commit.json").read_text())
subprocess.run(["git", "init", "-b", "r02-experiments", str(repo)], check=True, stdout=subprocess.DEVNULL)
(repo / ".git/info/exclude").write_text("__pycache__/\n.pytest_cache/\n*.pyc\n")

def put(kind, data, expected=None):
    raw = kind.encode() + b" " + str(len(data)).encode() + b"\0" + data
    sha = hashlib.sha1(raw).hexdigest()
    if expected is not None:
        assert sha == expected, (kind, sha, expected)
    target = repo / ".git/objects" / sha[:2] / sha[2:]
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes(zlib.compress(raw))
    return sha

entries = {e["path"]: e for e in tree["tree"]}
materialized = []
for p in sorted(repo.rglob("*")):
    rel = p.relative_to(repo).as_posix()
    if p.is_file() and rel in entries:
        e = entries[rel]
        assert e["type"] == "blob"
        put("blob", p.read_bytes(), e["sha"])
        materialized.append(rel)

directories = {"": commit["tree"]["sha"]}
directories.update({p: e["sha"] for p, e in entries.items() if e["type"] == "tree"})
for directory, expected in directories.items():
    children = []
    for path, e in entries.items():
        parent, _, name = path.rpartition("/")
        if parent == directory:
            key = (name + ("/" if e["type"] == "tree" else "")).encode()
            children.append((key, e, name))
    data = b"".join(
        e["mode"].lstrip("0").encode() + b" " + name.encode() + b"\0" + bytes.fromhex(e["sha"])
        for _, e, name in sorted(children)
    )
    put("tree", data, expected)

payload = commit["verification"]["payload"]
head, message = payload.split("\n\n", 1)
signature = commit["verification"]["signature"].split("\n")
gpgsig = "gpgsig " + signature[0] + "\n" + "\n".join(" " + s for s in signature[1:])
raw_commit = (head + "\n" + gpgsig + "\n\n" + message).encode()
put("commit", raw_commit, commit["sha"])
(repo / ".git/refs/heads/r02-experiments").write_text(commit["sha"] + "\n")
(repo / ".git/shallow").write_text(commit["sha"] + "\n")
subprocess.run(["git", "-C", str(repo), "config", "core.sparseCheckout", "true"], check=True)
subprocess.run(["git", "-C", str(repo), "config", "core.sparseCheckoutCone", "false"], check=True)
(repo / ".git/info/sparse-checkout").write_text("".join("/" + p + "\n" for p in materialized))
subprocess.run(["git", "-C", str(repo), "read-tree", "-m", "-u", "HEAD"], check=True)
status = subprocess.check_output(["git", "-C", str(repo), "status", "--porcelain"], text=True)
assert not status, status
print(json.dumps({"commit": commit["sha"], "tree": commit["tree"]["sha"], "verified_blobs": len(materialized), "verified_trees": len(directories), "git_status": status, "method": "GitHub API; byte-identical signed commit and trees; local sparse checkout; no remote configured"}, indent=2))
