"""Small ablations over identical grounded inputs, not production engines.

Conditional graph: unary dynamic preconditions only, confirmed guards only.
AND-OR: monotone reachability with first-support witness, NO optimal-C claim.
Neither imports AWG. Grounding, real AD semantics and provenance ingestion are
deliberately NOT implemented here and their costs are not timed as engine wins.
"""
from collections import defaultdict, deque
import heapq


def conditional_graph(p):
    # Sound implication reduction in this finite add-only model. For example,
    # member(V,G) implies usable(V) if EVERY producer of that membership requires
    # usable(V); retaining both would unfairly reject a simple credential chain.
    # Independent RBCD service/descriptor branches remain a true conjunction.
    facts=set(p.initial)|set(p.goals)
    for a in p.actions:facts.update(a.requires|a.adds)
    must={f:set(p.initial)|{f} for f in facts}
    producers={f:[a for a in p.actions if f in a.adds and all(v is True for _,v in a.guards)] for f in facts}
    changed=True
    while changed:
        changed=False
        for f in sorted(facts-p.initial):
            if not producers[f]:continue
            guarantees=[]
            for a in producers[f]:
                guarantee=set(a.adds)|set(a.requires)|set(p.initial)
                for r in a.requires:guarantee.update(must[r])
                guarantees.append(guarantee)
            extra=set.intersection(*guarantees)-must[f]
            if extra:must[f].update(extra);changed=True
    dynamic={}
    for a in p.actions:
        required=set(a.requires-p.initial)
        for f in sorted(required):
            if f in required and any(f in must[g] for g in required-{f}):required.remove(f)
        dynamic[a.name]=required
    unsupported = [a.name for a in p.actions if len(dynamic[a.name]) > 1]
    if unsupported or len(p.goals - p.initial) > 1:
        return {"status": "unsupported", "reason": "multiple accumulated prerequisites", "actions": unsupported}
    positive = defaultdict(int)
    for a in p.actions:
        for w in a.work:
            if p.costs[w] > 0:
                positive[w] += 1
    shared = sorted(w for w, count in positive.items() if count > 1)
    outgoing = defaultdict(list)
    for a in p.actions:
        if any(v is not True for _, v in a.guards):
            continue
        source = next(iter(dynamic[a.name]), "ROOT")
        for effect in sorted(a.adds):
            outgoing[source].append((effect, a.name, sum(p.costs[w] for w in a.work)))
    queue = [(0.0, "ROOT", ())] + [(0.0, f, ()) for f in sorted(p.initial)]
    heapq.heapify(queue)
    distance = {}
    while queue:
        cost, f, trace = heapq.heappop(queue)
        if f in distance:
            continue
        distance[f] = (cost, trace)
        for effect, a, increment in outgoing[f]:
            if effect not in distance:
                heapq.heappush(queue, (cost + increment, effect, trace + (a,)))
    needed = p.goals - p.initial
    goal = next(iter(needed), None)
    reached = goal is None or goal in distance
    trace = () if goal is None else distance.get(goal, (None, ()))[1]
    valid, diagnostic = p.check(trace) if reached else (True, "no witness")
    return {"status": "executed", "reachable": reached, "witness": list(trace), "witness_valid": valid,
            "min_C": None if shared or not reached else p.cost(trace),
            "C_status": "unsupported shared-work cost" if shared else "exact additive unary domain",
            "edge_local_C": distance[goal][0] if reached and goal is not None else None,
            "shared_units": shared, "reduced_dynamic_prerequisites":{k:sorted(v) for k,v in dynamic.items()},
            "diagnostic": diagnostic if not valid else None}


def and_or(p):
    known = set(p.initial)
    remaining = [set(a.requires) - known for a in p.actions]
    watching = defaultdict(list)
    support = {}
    for i, prerequisites in enumerate(remaining):
        for fact in prerequisites:
            watching[fact].append(i)
    pending = deque(i for i, missing in enumerate(remaining) if not missing)
    fired = set()
    order = []
    while pending:
        i = pending.popleft()
        if i in fired:
            continue
        a = p.actions[i]
        fired.add(i)
        if any(value is not True for _, value in a.guards):
            continue
        order.append(a.name)
        for fact in sorted(a.adds - known):
            known.add(fact)
            support[fact] = i
            for j in watching[fact]:
                remaining[j].discard(fact)
                if not remaining[j]:
                    pending.append(j)
    reached = p.goals <= known
    needed = set()
    def collect(fact):
        if fact in p.initial:
            return
        i = support[fact]
        if i in needed:
            return
        for prerequisite in p.actions[i].requires:
            collect(prerequisite)
        needed.add(i)
    if reached:
        for f in p.goals:
            collect(f)
    trace = [name for name in order if any(p.actions[i].name == name for i in needed)]
    valid, diagnostic = p.check(trace) if reached else (True, "no witness")
    return {"status": "executed", "reachable": reached, "witness": trace, "witness_valid": valid,
            "witness_C": p.cost(trace) if reached else None, "min_C": None,
            "C_status": "not optimized", "reachable_facts": sorted(known),
            "actions_examined": len(fired), "diagnostic": diagnostic if not valid else None}
