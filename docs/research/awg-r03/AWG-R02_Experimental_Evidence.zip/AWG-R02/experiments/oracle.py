"""Independent finite oracle. No imports from AWG, graph generators, or rating code.

Scope: grounded, deterministic, add-only actions; one authentication context per
problem. Exhaust all EXECUTABLE action subsets, not graph-node paths. At most 12
actions in the audit cases. Numeric C is an explicit synthetic work ledger.
"""
from dataclasses import dataclass, field
from collections import deque


@dataclass(frozen=True)
class Action:
    name: str
    requires: frozenset[str]
    adds: frozenset[str]
    work: frozenset[str] = frozenset()
    guards: tuple[tuple[str, bool | None], ...] = ()

    def status(self, facts):
        if not self.requires <= facts or any(v is False for _, v in self.guards):
            return "blocked"
        if any(v is None for _, v in self.guards):
            return "unknown"
        return "applicable"


@dataclass
class Problem:
    name: str
    initial: frozenset[str]
    goals: frozenset[str]
    actions: tuple[Action, ...]
    costs: dict[str, float] = field(default_factory=dict)

    def cost(self, trace):
        by_name = {a.name: a for a in self.actions}
        units = set().union(*(by_name[n].work for n in trace)) if trace else set()
        return sum(self.costs[w] for w in units)

    def check(self, trace, *, require_goal=True):
        facts = set(self.initial)
        seen = set()
        by_name = {a.name: a for a in self.actions}
        for name in trace:
            if name not in by_name:
                return False, f"unmodelled action {name}"
            a = by_name[name]
            if a.status(facts) != "applicable":
                return False, f"invalid step {name}: {a.status(facts)}"
            # Repeated passive transitions can be harmless; costs remain a union.
            seen.add(name)
            facts.update(a.adds)
        if require_goal and not self.goals <= facts:
            return False, "goal missing"
        return True, sorted(facts)


def exhaustive(problem):
    """Enumerate reachable subsets. Minimum is exact only in this finite model."""
    n = len(problem.actions)
    assert n <= 12
    pending = deque([(0, problem.initial, ())])
    seen = {0}
    successes = []
    all_facts = set(problem.initial)
    statuses = {a.name: set() for a in problem.actions}
    while pending:
        mask, facts, trace = pending.popleft()
        if problem.goals <= facts:
            successes.append((problem.cost(trace), trace))
        for i, action in enumerate(problem.actions):
            if mask & (1 << i):
                continue
            status = action.status(facts)
            statuses[action.name].add(status)
            if status != "applicable":
                continue
            next_mask = mask | (1 << i)
            next_facts = facts | action.adds
            all_facts.update(next_facts)
            if next_mask not in seen:
                seen.add(next_mask)
                pending.append((next_mask, next_facts, trace + (action.name,)))
    successes.sort(key=lambda v: (v[0], len(v[1]), v[1]))
    return {
        "reachable": bool(successes),
        "min_C": successes[0][0] if successes else None,
        "witness": list(successes[0][1]) if successes else [],
        "states": len(seen),
        "reachable_facts": sorted(all_facts),
        "statuses": {k: sorted(v) for k, v in statuses.items()},
    }


def all_goal_traces(problem):
    """Only for the five-action RBCD case; stop at the first goal in each trace."""
    found = []
    def visit(facts, trace):
        if problem.goals <= facts:
            found.append(trace)
            return
        for a in problem.actions:
            if a.name not in trace and a.status(facts) == "applicable":
                visit(facts | a.adds, trace + (a.name,))
    visit(problem.initial, ())
    return sorted(found)
