"""Separate profile of cached rating/replay; no search re-execution."""
import cProfile
import pstats
from unittest.mock import patch

from profile_pipeline import BASE, EVIDENCE, catalog_cache, fixture, save
from src.engine.query import MaterializedQuery, materialize_query


def main():
    load,q,metadata=fixture('rbcd-padding-1000')
    with catalog_cache(True):
        g=load();m=materialize_query(q,g);search=m.search(g)
        with patch.object(MaterializedQuery,'search',return_value=search):
            profiler=cProfile.Profile();result=profiler.runcall(m.run,g)
        assert result.final_goal_reached and len(result.paths)==3
        profiler.dump_stats(str(EVIDENCE/'f2-profile-rating-padding-cache.pstats'))
        stats=pstats.Stats(profiler)
        rows=[]
        for (file,line,name),(primitive,total,own,cumulative,callers) in stats.stats.items():
            rows.append(dict(file=file.replace(str(BASE),'baseline'),line=line,name=name,primitive_calls=primitive,calls=total,own_seconds=own,cumulative_seconds=cumulative))
        rows.sort(key=lambda x:x['cumulative_seconds'],reverse=True)
        save('f2-profile-rating-padding-cache.json',dict(total_seconds=stats.total_tt,total_calls=stats.total_calls,top_cumulative=rows[:45],
            selected=[r for r in rows if r['name'] in {'from_canonical','_load_contract','validate_graph','deepcopy','replay_path','verify_search_envelope','__getitem__','validate_binding','validate_catalog','safe_load','graph_digest'}]))
    print('cached padding rating/replay profiled',stats.total_tt)


if __name__=='__main__':main()
